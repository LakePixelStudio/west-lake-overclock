const storageKey = 'westlake-mobile-controls';
const ratio = (value) => Math.max(0, Math.min(1, value));
const sensitivity = (value) => Number.isFinite(value) ? Math.max(.3, Math.min(2.5, value)) : 1;

function loadSettings() {
  let saved;
  try { saved = JSON.parse(localStorage.getItem(storageKey)); } catch {}
  const positions = { foot: {}, drive: {} };
  for (const mode of Object.keys(positions)) {
    for (const [id, point] of Object.entries(saved?.positions?.[mode] ?? {})) {
      if (!/^(stick|b[A-Z][a-zA-Z]*)$/.test(id) || !Array.isArray(point) || point.length !== 2 || !point.every(Number.isFinite)) continue;
      positions[mode][id] = point.map(ratio);
    }
  }
  return {
    lookSensitivity: sensitivity(saved?.lookSensitivity),
    buttonLook: typeof saved?.buttonLook === 'boolean' ? saved.buttonLook : true,
    gyroSensitivity: sensitivity(saved?.gyroSensitivity),
    positions,
  };
}

const css = `
#mobile-settings-button,#mobile-settings{position:fixed;z-index:5;pointer-events:auto;color:#f6f3ea;font:500 14px/1.35 "Segoe UI","Microsoft YaHei",sans-serif;text-shadow:none}
#mobile-settings-button{left:50%;bottom:max(12px,env(safe-area-inset-bottom));transform:translateX(-50%);width:44px;height:44px;border:1px solid #ab9b73;border-radius:50%;background:#211e19;color:#ffe0a2;font-size:25px;touch-action:manipulation}
#mobile-settings{left:50%;top:50%;transform:translate(-50%,-50%);width:min(340px,calc(100vw - 24px));max-height:calc(100vh - 24px);max-height:calc(100dvh - 24px);box-sizing:border-box;overflow:auto;overscroll-behavior:contain;padding:14px;background:#1c1c1d;border:1px solid #ab9b73;border-radius:12px;box-shadow:0 8px 28px #0008;user-select:none;color-scheme:dark}
#mobile-settings[hidden],#mobile-settings-button[hidden]{display:none}
#mobile-settings .mobile-settings-header,#mobile-settings .mobile-settings-actions{display:flex;align-items:center;justify-content:space-between;gap:8px}
#mobile-settings h2{margin:0;font-size:17px;color:#ffe0a2}
#mobile-settings label{display:flex;align-items:center;gap:8px;min-height:40px;margin:4px 0}
#mobile-settings input{accent-color:#ffbf63;min-width:0}
#mobile-settings input[type=range]{flex:1}
#mobile-settings input[type=checkbox]{width:19px;height:19px;margin-left:0}
#mobile-settings output{min-width:3em;text-align:right;font-variant-numeric:tabular-nums}
#mobile-settings button{min-height:40px;padding:5px 10px;color:inherit;font:inherit;background:#302d27;border:1px solid #857751;border-radius:6px;touch-action:manipulation}
#mobile-settings button[aria-pressed=true]{color:#21190d;background:#ffd18b;border-color:#ffd18b}
#mobile-settings button:disabled{opacity:.55}
#mobile-settings button:focus-visible,#mobile-settings-button:focus-visible{outline:2px solid #ffe0a2;outline-offset:2px}
#mobile-gyro-status,#mobile-layout-hint{margin:6px 0;color:#d6cbb8;font-size:12px}
#mobile-edit-layout{width:100%;margin-top:5px}
#mobile-settings.editing{top:max(8px,env(safe-area-inset-top));transform:translateX(-50%);width:max-content;max-width:calc(100vw - 16px);padding:7px 9px}
#mobile-layout-tools .mobile-settings-actions{justify-content:center;flex-wrap:wrap;gap:4px}
#mobile-layout-hint{text-align:center;margin-bottom:0}
@media (orientation:landscape) and (max-height:520px){#mobile-settings:not(.editing){width:min(480px,calc(100vw - 24px))}#mobile-settings label{min-height:32px;margin:2px 0}}
`;

export function createMobileSettings({ hud, onEditing, onChange, onGyroToggle, onGyroCenter, onOpen }) {
  const settings = loadSettings();
  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  const gear = document.createElement('button');
  gear.id = 'mobile-settings-button';
  gear.type = 'button';
  gear.textContent = '⚙';
  gear.setAttribute('aria-label', '触控设置');
  gear.setAttribute('aria-controls', 'mobile-settings');
  gear.setAttribute('aria-expanded', 'false');
  const panel = document.createElement('section');
  panel.id = 'mobile-settings';
  panel.setAttribute('aria-label', '触控设置');
  panel.hidden = true;
  panel.innerHTML = `
    <div id="mobile-settings-controls">
      <div class="mobile-settings-header"><h2>触控设置</h2><button id="mobile-settings-close" type="button">返回游戏</button></div>
      <label for="mobile-look-sensitivity">拖动灵敏度 <input id="mobile-look-sensitivity" type="range" min="0.3" max="2.5" step="0.1"><output for="mobile-look-sensitivity"></output></label>
      <label for="mobile-button-look"><input id="mobile-button-look" type="checkbox"> 按住动作键也能拖动视角</label>
      <label for="mobile-gyro-sensitivity">陀螺仪灵敏度 <input id="mobile-gyro-sensitivity" type="range" min="0.3" max="2.5" step="0.1"><output for="mobile-gyro-sensitivity"></output></label>
      <div class="mobile-settings-actions"><button id="mobile-gyro-toggle" type="button" aria-describedby="mobile-gyro-status">启用陀螺仪</button><button id="mobile-gyro-center" type="button" disabled>重置陀螺仪基准</button></div>
      <p id="mobile-gyro-status" role="status">陀螺仪已关闭</p>
      <button id="mobile-edit-layout" type="button">调整按钮位置</button>
    </div>
    <div id="mobile-layout-tools" hidden>
      <div class="mobile-settings-actions">
        <button id="mobile-layout-foot" type="button" aria-pressed="false">步行</button>
        <button id="mobile-layout-drive" type="button" aria-pressed="false">驾驶</button>
        <button id="mobile-layout-reset" type="button">恢复默认</button>
        <button id="mobile-layout-done" type="button">完成</button>
      </div>
      <p id="mobile-layout-hint">拖动摇杆或按钮，位置自动保存</p>
    </div>`;
  hud.append(gear, panel);

  const get = (id) => panel.querySelector('#' + id);
  const controls = get('mobile-settings-controls'), tools = get('mobile-layout-tools');
  const closeButton = get('mobile-settings-close'), editButton = get('mobile-edit-layout');
  const footButton = get('mobile-layout-foot'), driveButton = get('mobile-layout-drive');
  const gyroToggle = get('mobile-gyro-toggle'), gyroCenter = get('mobile-gyro-center');
  const gyroStatus = get('mobile-gyro-status');
  let editMode = null, gyroActive = false;

  function save() {
    try { localStorage.setItem(storageKey, JSON.stringify(settings)); } catch {}
  }

  function changed() {
    save();
    onChange(settings);
  }

  function setEditing(mode) {
    editMode = mode;
    const editing = !!mode;
    panel.classList.toggle('editing', editing);
    controls.hidden = editing;
    tools.hidden = !editing;
    footButton.setAttribute('aria-pressed', String(mode === 'foot'));
    driveButton.setAttribute('aria-pressed', String(mode === 'drive'));
    onEditing(mode);
  }

  function close() {
    if (panel.hidden) return;
    if (editMode) setEditing(null);
    panel.hidden = true;
    gear.hidden = false;
    gear.setAttribute('aria-expanded', 'false');
    save();
    onOpen(false);
    gear.focus();
  }

  function open() {
    if (!panel.hidden) return;
    panel.hidden = false;
    gear.hidden = true;
    gear.setAttribute('aria-expanded', 'true');
    onOpen(true);
    closeButton.focus();
  }

  gear.addEventListener('click', open);
  closeButton.addEventListener('click', close);
  panel.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { event.stopPropagation(); close(); }
  });

  for (const [id, key] of [['mobile-look-sensitivity', 'lookSensitivity'], ['mobile-gyro-sensitivity', 'gyroSensitivity']]) {
    const slider = get(id), output = slider.nextElementSibling;
    slider.value = settings[key];
    output.value = Number(slider.value).toFixed(1) + '×';
    slider.addEventListener('input', () => {
      settings[key] = Number(slider.value);
      output.value = settings[key].toFixed(1) + '×';
      changed();
    });
  }
  const buttonLook = get('mobile-button-look');
  buttonLook.checked = settings.buttonLook;
  buttonLook.addEventListener('change', () => { settings.buttonLook = buttonLook.checked; changed(); });

  const setGyroStatus = (message) => { gyroStatus.textContent = message; };
  gyroToggle.addEventListener('click', async () => {
    const enable = !gyroActive;
    gyroToggle.disabled = true;
    if (enable) setGyroStatus('正在启用陀螺仪…');
    try {
      const permitted = await onGyroToggle(enable);
      gyroActive = enable && !!permitted;
      if (!enable) setGyroStatus('陀螺仪已关闭');
    } catch {
      gyroActive = false;
      setGyroStatus('无法启用陀螺仪');
    } finally {
      gyroToggle.disabled = false;
      gyroToggle.textContent = gyroActive ? '关闭陀螺仪' : '启用陀螺仪';
      gyroCenter.disabled = !gyroActive;
    }
  });
  gyroCenter.addEventListener('click', onGyroCenter);

  editButton.addEventListener('click', () => { setEditing('foot'); footButton.focus(); });
  footButton.addEventListener('click', () => { if (editMode) setEditing('foot'); });
  driveButton.addEventListener('click', () => { if (editMode) setEditing('drive'); });
  get('mobile-layout-reset').addEventListener('click', () => {
    if (!editMode) return;
    settings.positions[editMode] = {};
    changed();
  });
  get('mobile-layout-done').addEventListener('click', () => { setEditing(null); save(); editButton.focus(); });

  return { settings, save, setGyroStatus, open, close };
}
