import { BOAT_ROUTE, PIER_HUBIN, PIER_LEIFENG, RING, groundY, makeStrip, nearest, pointAt, walkable } from './geo.js';

const route = makeStrip(BOAT_ROUTE, 0);
const ring = makeStrip([...RING, RING[0]], 0);
const piers = [PIER_HUBIN, PIER_LEIFENG];
const docks = piers.map((pier) => ({
  access: pointAt(pier, 2),
  end: pointAt(pier, pier.len - 1.5),
}));
const seats = [[-0.62, -3.2], [0.62, -3.2], [-0.62, -1.9], [0.62, -1.9], [-0.62, 1.9], [0.62, 1.9]];
const boatSpeed = 27;
const walkSpeed = 7;
const boardingSeconds = 2.5;

function crossesWater(x, z, gx, gz, distance) {
  const steps = Math.ceil(distance / 55);
  for (let i = 1; i < steps; i++) {
    if (!walkable(x + (gx - x) * i / steps, z + (gz - z) * i / steps)) return true;
  }
  return false;
}

function isLanding(ferry) {
  for (const ride of ferry.riders.values()) if (ride.phase === 'landing') return true;
  return false;
}

export function createBotTransit({ world, blocked }) {
  const ferries = [-6, 6].map((offset, index) => {
    const model = world.makeBoat(1.7);
    world.solids.add(model);
    return { index, offset, model, riders: new Map() };
  });
  const waiting = new Map();
  const approaching = new Map();
  let time = 0, idleSince = 0;

  function positionFerry(ferry, dt) {
    const [x, z, dx, dz] = pointAt(route, ferry.s);
    const heading = Math.atan2(dx * ferry.dir, dz * ferry.dir);
    const turn = heading - ferry.yaw;
    ferry.yaw = dt ? ferry.yaw + Math.atan2(Math.sin(turn), Math.cos(turn)) * Math.min(1, dt * 2.5) : heading;
    ferry.model.position.set(x - dz * ferry.offset, 0.12 + Math.sin(time * 0.9 + ferry.index) * 0.05, z + dx * ferry.offset);
    ferry.model.rotation.set(0, ferry.yaw, Math.sin(time * 0.7 + ferry.index) * 0.02);
  }

  function reset() {
    waiting.clear(); approaching.clear(); time = idleSince = 0;
    for (const ferry of ferries) {
      for (const bot of ferry.riders.keys()) { bot.transitRide = null; bot.waterCombat = false; }
      ferry.riders.clear();
      ferry.dock = ferry.index; ferry.destination = null; ferry.s = ferry.index ? route.len : 0;
      ferry.dir = ferry.index ? -1 : 1; ferry.speed = ferry.holdUntil = 0; ferry.serviceAt = null;
      positionFerry(ferry);
    }
  }

  function plan(bot, goal) {
    approaching.delete(bot);
    if (!goal || bot.transitRide) return null;
    const { x, z } = bot.pos;
    const distance = Math.hypot(x - goal.x, z - goal.z);
    if (distance < 900 || !crossesWater(x, z, goal.x, goal.z, distance)) return null;
    const costs = docks.map(({ access: [px, pz] }) => [Math.hypot(x - px, z - pz), Math.hypot(goal.x - px, goal.z - pz)]);
    const [origin, target] = costs[0][0] + costs[1][1] <= costs[1][0] + costs[0][1] ? [0, 1] : [1, 0];
    const [walkTo] = costs[origin], [, walkFrom] = costs[target];
    if (walkTo > 1400 || walkFrom > 1400) return null;
    const a = nearest(ring.pts, ring.cum, x, z), b = nearest(ring.pts, ring.cum, goal.x, goal.z);
    const along = Math.abs(a.s - b.s);
    const overland = Math.max(distance, a.d + b.d + Math.min(along, ring.len - along)) / walkSpeed;
    let waitSeconds = Infinity;
    for (const ferry of ferries) {
      if (ferry.dock === origin && ferry.riders.size < seats.length) { waitSeconds = Math.max(0, ferry.holdUntil - time); break; }
      const remaining = ferry.dir > 0 ? route.len - ferry.s : ferry.s;
      const travel = ferry.destination === origin ? remaining : route.len + (ferry.destination === null ? 0 : remaining);
      waitSeconds = Math.min(waitSeconds, travel / boatSpeed + 10);
    }
    const ferryTime = (walkTo + walkFrom + piers[origin].len + piers[target].len) / walkSpeed + route.len / boatSpeed + waitSeconds;
    if (ferryTime > overland * 1.25) return null;
    const pier = piers[origin], dock = docks[origin];
    const atPier = nearest(pier.pts, pier.cum, x, z);
    const boarding = walkTo < 3 || (atPier.s > 1.5 && atPier.d < 1.75);
    const [px, pz] = boarding ? dock.end : dock.access;
    if (Math.hypot(x - dock.end[0], z - dock.end[1]) < 100) approaching.set(bot, { dock: origin, until: time + 1.2 });
    return { x: px, z: pz, from: origin, boarding, waitSeconds };
  }

  function board(bot, stop) {
    if (!bot.alive || !stop?.boarding || bot.transitRide) return false;
    const [x, z] = docks[stop.from].end;
    if (Math.hypot(bot.pos.x - x, bot.pos.z - z) > 2.6) return false;
    approaching.delete(bot);
    const ferry = ferries.find((candidate) => candidate.dock === stop.from && candidate.riders.size < seats.length && !isLanding(candidate));
    if (!ferry) { waiting.set(bot, { dock: stop.from, until: time + 1.2 }); return true; }
    waiting.delete(bot);
    const occupied = new Set([...ferry.riders.values()].map((ride) => ride.seat));
    const seat = seats.findIndex((_, i) => !occupied.has(i));
    const ride = { phase: 'boarding', seat, progress: 0, x: bot.pos.x, y: bot.pos.y, z: bot.pos.z };
    ferry.riders.set(bot, ride);
    ferry.holdUntil = time + boardingSeconds + 1.2;
    bot.transitRide = ride;
    bot.waterCombat = false;
    bot.vel.set(0, 0, 0);
    return true;
  }

  function landingPoint(dock, seat) {
    const pier = piers[dock];
    for (let i = 0; i < 4; i++) {
      const [x, z, dx, dz] = pointAt(pier, pier.len - 1.5 - Math.floor(seat / 2) * 2 - i * 2);
      const side = seat % 2 ? 0.75 : -0.75;
      const px = x - dz * side, pz = z + dx * side, y = groundY(px, pz);
      if (!blocked(px, y, pz)) return [px, y, pz];
    }
    const [x, z] = docks[dock].end;
    return [x, groundY(x, z), z];
  }

  function depart(ferry) {
    ferry.destination = 1 - ferry.dock;
    ferry.dir = ferry.dock ? -1 : 1;
    ferry.dock = null;
    ferry.serviceAt = null;
    for (const [bot, ride] of ferry.riders) {
      ride.phase = 'sailing';
      bot.waterCombat = true;
    }
  }

  function arrive(ferry) {
    ferry.dock = ferry.destination;
    ferry.destination = null;
    ferry.holdUntil = time + boardingSeconds;
    ferry.speed = 0;
    for (const [bot, ride] of ferry.riders) {
      ride.phase = 'landing';
      ride.progress = 0;
      [ride.x, ride.y, ride.z] = landingPoint(ferry.dock, ride.seat);
      bot.waterCombat = false;
    }
  }

  function updateRiders(ferry, dt) {
    const { position, rotation } = ferry.model;
    const sin = Math.sin(rotation.y), cos = Math.cos(rotation.y);
    for (const [bot, ride] of ferry.riders) {
      if (!bot.alive) {
        ferry.riders.delete(bot); bot.transitRide = null; bot.waterCombat = false;
        continue;
      }
      const [seatX, seatZ] = seats[ride.seat];
      const x = position.x + cos * seatX + sin * seatZ, y = position.y + 0.48, z = position.z - sin * seatX + cos * seatZ;
      const moving = ride.phase === 'sailing';
      const t = moving ? 0 : Math.min(1, ride.progress += dt / boardingSeconds);
      const mix = t * t * (3 - 2 * t);
      const blend = ride.phase === 'boarding' ? 1 - mix : mix;
      const px = moving ? x : x + (ride.x - x) * blend;
      const py = moving ? y : y + (ride.y - y) * blend;
      const pz = moving ? z : z + (ride.z - z) * blend;
      bot.vel.set((px - bot.pos.x) / dt, (py - bot.pos.y) / dt, (pz - bot.pos.z) / dt);
      bot.pos.set(px, py, pz);
      if (!bot.target) bot.yaw = rotation.y;
      if (ride.phase === 'landing' && t === 1) {
        ferry.riders.delete(bot); bot.transitRide = null; bot.waterCombat = false;
      }
    }
  }

  function update(dt) {
    if (!(dt > 0)) return;
    time += dt;
    const requested = [false, false];
    for (const [bot, request] of waiting) {
      const [x, z] = docks[request.dock].end;
      if (!bot.alive || request.until < time || Math.hypot(bot.pos.x - x, bot.pos.z - z) > 4) waiting.delete(bot);
      else requested[request.dock] = true;
    }
    const expected = [false, false];
    for (const [bot, request] of approaching) {
      if (!bot.alive || request.until < time) approaching.delete(bot);
      else expected[request.dock] = true;
    }
    const idle = ferries.every((ferry) => ferry.dock !== null && !ferry.riders.size && ferry.serviceAt === null);
    if (idle && time - idleSince >= 18) {
      for (const ferry of ferries) ferry.serviceAt = time + 7 * ferry.index;
    } else if (!idle) idleSince = time;
    for (const ferry of ferries) {
      if (ferry.dock !== null && time >= ferry.holdUntil && !isLanding(ferry)) {
        const other = 1 - ferry.dock;
        const demand = requested[other] && !ferries.some((candidate) => candidate.dock === other || candidate.destination === other);
        const serviceDue = ferry.serviceAt !== null && time >= ferry.serviceAt && (!expected[ferry.dock] || time >= ferry.serviceAt + 15);
        if (ferry.riders.size || (demand && !expected[ferry.dock]) || serviceDue) depart(ferry);
      }
      if (ferry.destination !== null) {
        const distance = ferry.dir > 0 ? route.len - ferry.s : ferry.s;
        const speed = Math.max(3, Math.min(boatSpeed, distance * 0.25));
        ferry.speed += Math.sign(speed - ferry.speed) * Math.min(Math.abs(speed - ferry.speed), 5 * dt);
        ferry.s += ferry.dir * Math.min(distance, ferry.speed * dt);
        if (distance <= ferry.speed * dt) arrive(ferry);
      }
      positionFerry(ferry, dt);
      updateRiders(ferry, dt);
    }
  }

  reset();
  return { update, plan, board, reset, ferries: ferries.map(({ model }) => model) };
}
