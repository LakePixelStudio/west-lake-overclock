# Vehicle model credits

- [Tesla 2018 Model 3](https://sketchfab.com/3d-models/tesla-2018-model-3-5ef9b845aaf44203b6d04e2c677e444f) by [Ameer Studio](https://sketchfab.com/uchiha.321abc).
- [2024 BYD Seal Performance AWD](https://sketchfab.com/3d-models/2024-byd-seal-performance-awd-96ec5c34852f4c3090a755d4445f5e98) by [Nazh Design ✔](https://sketchfab.com/NazhDesign).
- [Toyota Camry 40](https://sketchfab.com/3d-models/toyota-camry-40-560c174d073f4a10bb153ded41ada8c9) by [mamont nikita](https://sketchfab.com/mamontnikita62), credited as Ford mondeo in the original download list.

All three source models are licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). The copies bundled with West Lake Overclock were scaled and reoriented for the game, regrouped for wheel animation, and optimized for rendering.
