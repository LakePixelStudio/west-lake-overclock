# 西湖 · OVERCLOCK

打开 GitHub Pages 站点即可在浏览器中游玩。开场界面也提供 [Windows 离线版](./West-Lake-80-Players.zip)。

地图数据 © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright)，按 [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/) 提供。浏览器使用的地图数据见 geo.js、hubin_data.js、shops_data.js 和 metro-data.js。

车辆模型作者和许可见 [车辆模型来源](./vehicle-assets/CREDITS.md)。Three.js 的 MIT 许可见 [Three.js LICENSE](./vendor/three/LICENSE)。

## 手机触控

手机或平板请用 HTTPS 地址打开游戏。在开始界面点「触控设置」，或在游戏内点齿轮。需要陀螺仪时点「启用陀螺仪」，并在浏览器弹窗中允许访问设备方向。点「调整按钮位置」可以分别拖动步行和驾驶的摇杆与按键，布局会自动保存。点「返回游戏」关闭设置后即可操作角色。

## 部署到 GitHub Pages

1. 解压此 ZIP。把解压后的全部内容上传到仓库 `main` 分支根目录，保留原文件夹结构。
2. 确认根目录有 `index.html`、`.nojekyll`、`West-Lake-80-Players.zip`，以及 `vendor`、`metro-assets`、`vehicle-assets` 和 `tool-icons` 文件夹。游戏页面需要这些文件一起发布。
3. 在仓库 Settings → Pages 中选择 Deploy from a branch，设为 `main` / `(root)` 并保存。部署成功后，从 Pages 页面给出的 HTTPS 地址打开游戏。

## 跨区追击版

跨区追击版包含 80 人分区开局和节奏更慢的 AI 追击。地图上共有 15 辆汽车和 3 艘渡轮，机器人会根据路线选择驾车、乘渡轮或步行。瞄准时镜框外围仍能看到环境。

游泳时，电脑按住 C 下潜，手机按住「下潜」，松开后上浮。
