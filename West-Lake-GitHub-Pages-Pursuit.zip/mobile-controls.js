import { Euler, Quaternion, Vector3 } from 'three';
import { createMobileSettings } from './mobile-settings.js';

const buttons = {
  bGas: '加速', bBrake: '刹车', bDrift: '漂移', bAuto: 'FSD',
  bFire: '开火', bJump: '跳跃', bDive: '下潜', bAim: '瞄准', bSwap: '换工具', bUse: '互动',
};
const layouts = {
  foot: ['stick', 'bFire', 'bJump', 'bAim', 'bSwap', 'bUse'],
  drive: ['stick', 'bGas', 'bBrake', 'bDrift', 'bAuto', 'bUse'],
};
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

const css = `
#touch{position:fixed;inset:0;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;
  --pad:clamp(8px,4vw,32px);--low:clamp(12px,7vh,56px);--small:clamp(50px,14vw,76px);--main:clamp(68px,19vw,104px);--stick:clamp(108px,33vw,150px);--gap:10px}
#touch [hidden],#touch.menu-open:not(.editing) .touch-control{display:none}
#hud.touch-settings-open > :not(#mobile-settings):not(#mobile-settings-button){visibility:hidden}
#touch .touch-control{position:absolute;box-sizing:border-box;touch-action:none}
#stick{left:var(--pad);bottom:var(--low);width:var(--stick);height:var(--stick);border-radius:50%;background:#ffffff20;border:2px solid #ffffff60}
#stick i{position:absolute;left:29%;top:29%;width:42%;height:42%;border-radius:50%;background:#ffffff90;pointer-events:none}
.tb{min-width:var(--small);height:var(--small);padding:0 8px;border-radius:50%;border:2px solid #ffffff88;background:#0a0e1478;color:#fff;font:600 14px "Segoe UI","Microsoft YaHei",sans-serif}
.tb.act{background:#ffb000bf;color:#111}
#bGas,#bFire{right:var(--pad);bottom:var(--low);width:var(--main);height:var(--main);font-size:17px}
#bJump,#bDive,#bBrake{right:calc(var(--pad) + var(--main) + var(--gap));bottom:var(--low)}
#bDrift,#bAim{right:var(--pad);bottom:calc(var(--low) + var(--main) + var(--gap))}
#bAuto,#bSwap{right:calc(var(--pad) + var(--main) + var(--gap));bottom:calc(var(--low) + var(--main) + var(--gap))}
#bUse{right:var(--pad);bottom:calc(var(--low) + var(--main) + var(--small) + 2 * var(--gap))}
#touch.editing .touch-control{border-style:dashed;cursor:move}
@media (orientation:landscape) and (max-height:480px){#touch{--main:clamp(60px,18vh,82px);--small:clamp(45px,13vh,60px);--stick:clamp(96px,31vh,135px);--low:clamp(10px,5vh,25px)}}`;

function createGyro({ canLook, status }) {
  const current = new Quaternion(), previous = new Quaternion(), inverse = new Quaternion(), delta = new Quaternion();
  const euler = new Euler(0, 0, 0, 'ZXY'), right = new Vector3();
  const rad = Math.PI / 180, pixelsPerRadian = 1 / .0021;
  let enabled = false, haveSample = false, timer, angle, dx = 0, dy = 0;
  function recenter() { haveSample = false; dx = dy = 0; }
  function sample(event) {
    const { alpha, beta, gamma } = event;
    if (![alpha, beta, gamma].every(Number.isFinite)) return;
    const screenAngle = window.screen.orientation?.angle ?? window.orientation ?? 0;
    current.setFromEuler(euler.set(beta * rad, gamma * rad, alpha * rad));
    if (haveSample && screenAngle === angle && canLook()) {
      delta.copy(current).multiply(inverse.copy(previous).invert());
      // Use the shortest rotation across the alpha wrap, with horizontal pitch along the screen's right axis.
      const sign = delta.w < 0 ? -1 : 1;
      const rotation = 2 * Math.acos(clamp(Math.abs(delta.w), 0, 1));
      if (rotation < .5) {
        const factor = rotation > 1e-6 ? sign * rotation / Math.sin(rotation / 2) : 2 * sign;
        right.set(Math.cos(screenAngle * rad), -Math.sin(screenAngle * rad), 0).applyQuaternion(previous);
        dx -= delta.z * factor * pixelsPerRadian;
        dy -= (delta.x * right.x + delta.y * right.y + delta.z * right.z) * factor * pixelsPerRadian;
      }
    }
    if (!haveSample) { clearTimeout(timer); status('陀螺仪已开启'); }
    previous.copy(current); angle = screenAngle; haveSample = true;
  }
  async function toggle(on) {
    clearTimeout(timer); recenter();
    if (!on) { enabled = false; window.removeEventListener('deviceorientation', sample); return false; }
    if (!window.isSecureContext || !window.DeviceOrientationEvent) {
      status('陀螺仪需要 HTTPS 和支持传感器的浏览器'); return false;
    }
    try {
      if (typeof window.DeviceOrientationEvent.requestPermission === 'function'
        && await window.DeviceOrientationEvent.requestPermission() !== 'granted') {
        status('未授予动作与方向访问权限'); return false;
      }
    } catch { status('未能获取动作与方向访问权限'); return false; }
    enabled = true;
    window.addEventListener('deviceorientation', sample);
    status('等待手机方向数据…');
    timer = setTimeout(() => { if (!haveSample) status('未收到方向数据，请检查浏览器的传感器权限'); }, 2500);
    return true;
  }
  function tick(dt, sensitivity, onLook) {
    if (!enabled || (!dx && !dy)) return;
    const blend = 1 - Math.exp(-dt / .018);
    const x = dx * blend, y = dy * blend;
    dx -= x; dy -= y;
    if (Math.abs(dx) < .01) dx = 0;
    if (Math.abs(dy) < .01) dy = 0;
    onLook(x * sensitivity, y * sensitivity);
  }
  return { toggle, recenter, tick };
}

export function createMobileControls({ hud, ui, onLook, onUse, onSwap, onMenuOpen, canPlay }) {
  const style = document.createElement('style'); style.textContent = css; document.head.append(style);
  const touch = document.createElement('div'); touch.id = 'touch';
  touch.innerHTML = '<div id="stick" class="touch-control" aria-label="摇杆"><i></i></div>'
    + Object.entries(buttons).map(([id, text]) => `<button type="button" class="tb touch-control" id="${id}">${text}</button>`).join('');
  document.body.append(touch);
  const controls = Object.fromEntries([...touch.children].map((element) => [element.id, element]));
  const stick = controls.stick, knob = stick.firstChild, pointers = new Map(), held = new Set();
  let stickId = null, lookId = null, editMode = null, mode = 'foot', dragX = 0, dragY = 0, car, riding, prompt, indoors, swimming, wet, ferry;
  ui.menuOpen = ui.gas = ui.brake = ui.jump = ui.jumpPressed = ui.firePressed = ui.dive = false;

  const gyro = createGyro({ canLook: () => canPlay() && !ui.menuOpen && !ui.big && !document.hidden,
    status: (text) => menu.setGyroStatus(text) });
  const menu = createMobileSettings({ hud,
    onEditing(next) { releaseAll(); editMode = next; touch.classList.toggle('editing', !!next); showControls(); },
    onChange: applyPositions,
    onGyroToggle: gyro.toggle,
    onGyroCenter: gyro.recenter,
    onOpen(open) {
      ui.menuOpen = open; releaseAll(); touch.classList.toggle('menu-open', open);
      if (open && ui.big) document.getElementById('map').click();
      hud.classList.toggle('touch-settings-open', open);
      showControls(); onMenuOpen(open);
    },
  });
  ui.settings = menu.settings;
  ui.openSettings = menu.open;

  function setButton(id, down) {
    if (down) held.add(id); else held.delete(id);
    controls[id].classList.toggle('act', down);
    switch (id) {
      case 'bGas': ui.gas = down; break;
      case 'bBrake': ui.brake = down; break;
      case 'bDrift': ui.jump = down; break;
      case 'bJump': ui.jump = down; if (down) ui.jumpPressed = true; break;
      case 'bDive': ui.dive = down; break;
      case 'bFire': ui.fire = down; if (down) ui.firePressed = true; break;
      case 'bAim': if (down) ui.aim = !ui.aim; break;
      case 'bAuto': if (down) ui.fsdTap = true; break;
      case 'bUse': if (down) onUse(); break;
      case 'bSwap': if (down) onSwap(); break;
    }
    if (id === 'bAim' || id === 'bAuto') highlightToggles();
  }

  function highlightToggles() {
    controls.bAim.classList.toggle('act', ui.aim);
    controls.bAuto.classList.toggle('act', !!car?.auto);
  }

  function release(pointerId) {
    const pointer = pointers.get(pointerId);
    if (!pointer) return;
    pointers.delete(pointerId);
    if (touch.hasPointerCapture(pointerId)) touch.releasePointerCapture(pointerId);
    if (pointerId === lookId) lookId = null;
    if (pointerId === stickId) { stickId = null; ui.moveX = ui.moveY = 0; knob.style.transform = ''; }
    if (pointer.kind === 'button') setButton(pointer.id, false);
    if (pointer.kind === 'edit') menu.save();
  }

  function releaseAll() {
    for (const pointerId of pointers.keys()) release(pointerId);
    ui.jumpPressed = ui.firePressed = ui.fsdTap = false;
    dragX = dragY = 0; gyro.recenter();
  }
  ui.releaseTouch = releaseAll;

  function applyPosition(id) {
    const control = controls[id], point = menu.settings.positions[editMode || mode][id === 'bDive' ? 'bJump' : id];
    if (!point) { control.style.left = control.style.top = control.style.right = control.style.bottom = control.style.transform = ''; return; }
    const halfW = control.offsetWidth / 2, halfH = control.offsetHeight / 2;
    control.style.left = clamp(point[0] * innerWidth, halfW, innerWidth - halfW) + 'px';
    control.style.top = clamp(point[1] * innerHeight, halfH, innerHeight - halfH) + 'px';
    control.style.right = control.style.bottom = 'auto';
    control.style.transform = 'translate(-50%, -50%)';
  }
  function applyPositions() { Object.keys(controls).forEach(applyPosition); }

  function moveStick(pointer, x, y) {
    const dx = x - pointer.cx, dy = y - pointer.cy, d = Math.hypot(dx, dy);
    const force = clamp((d - 4) / (pointer.radius - 4), 0, 1);
    ui.moveX = d ? dx / d * force : 0; ui.moveY = d ? -dy / d * force : 0;
    knob.style.transform = `translate(${ui.moveX * pointer.radius * .68}px,${-ui.moveY * pointer.radius * .68}px)`;
  }

  touch.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || (!editMode && (!canPlay() || ui.menuOpen || ui.big))) return;
    const id = e.target.closest('.touch-control')?.id;
    const pointer = { id, x: e.clientX, y: e.clientY, kind: 'look' };
    if (editMode) {
      if (!id || [...pointers.values()].some((p) => p.id === id)) return;
      const rect = controls[id].getBoundingClientRect();
      pointer.kind = 'edit'; pointer.offsetX = e.clientX - rect.left - rect.width / 2; pointer.offsetY = e.clientY - rect.top - rect.height / 2;
    } else if (id === 'stick') {
      if (stickId !== null) return;
      const rect = stick.getBoundingClientRect();
      pointer.kind = 'stick'; pointer.cx = rect.left + rect.width / 2; pointer.cy = rect.top + rect.height / 2;
      pointer.radius = rect.width * .42; stickId = e.pointerId;
      moveStick(pointer, e.clientX, e.clientY);
    } else if (id) {
      if (held.has(id)) return;
      pointer.kind = 'button'; setButton(id, true);
    }
    pointers.set(e.pointerId, pointer);
    touch.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  touch.addEventListener('pointermove', (e) => {
    const p = pointers.get(e.pointerId);
    if (!p) return;
    const x = e.clientX, y = e.clientY;
    if (p.kind === 'stick') moveStick(p, x, y);
    else if (p.kind === 'edit') {
      menu.settings.positions[editMode][p.id] = [clamp((x - p.offsetX) / innerWidth, 0, 1), clamp((y - p.offsetY) / innerHeight, 0, 1)];
      applyPosition(p.id);
    } else if (p.kind === 'look' || menu.settings.buttonLook) {
      if (lookId !== null && lookId !== e.pointerId) { p.x = x; p.y = y; return; }
      if (lookId === null && p.kind === 'button' && Math.hypot(x - p.x, y - p.y) < 4) return;
      lookId = e.pointerId;
      dragX += x - p.x; dragY += y - p.y;
      p.x = x; p.y = y;
    }
  });
  touch.addEventListener('pointerup', (e) => release(e.pointerId));
  for (const event of ['pointercancel', 'lostpointercapture']) touch.addEventListener(event, (e) => {
    if (!pointers.has(e.pointerId)) return;
    release(e.pointerId); ui.jumpPressed = ui.firePressed = ui.fsdTap = false;
  });
  window.addEventListener('blur', releaseAll);
  document.addEventListener('visibilitychange', releaseAll);
  window.addEventListener('resize', () => { releaseAll(); applyPositions(); });
  ui.tickInput = (dt) => {
    if (ui.menuOpen || ui.big) return;
    if (dragX || dragY) {
      const scale = 2.2 * menu.settings.lookSensitivity;
      onLook(dragX * scale, dragY * scale); dragX = dragY = 0;
    }
    gyro.tick(dt, menu.settings.gyroSensitivity, onLook);
  };

  function showControls() {
    const toolReady = !car && (!riding || ferry) && !indoors;
    const visible = editMode ? layouts[editMode] : [
      !riding && 'stick', car && 'bGas', car && 'bBrake', car && 'bDrift', car?.type.id === 'tesla' && 'bAuto',
      toolReady && !wet && 'bFire', toolReady && !wet && 'bAim',
      !car && !riding && !indoors && (swimming ? 'bDive' : 'bJump'), toolReady && 'bSwap',
      (car || prompt || riding) && 'bUse',
    ];
    for (const [id, el] of Object.entries(controls)) el.hidden = !visible.includes(id);
    for (const [pointerId, p] of pointers) if (p.id && controls[p.id].hidden) release(pointerId);
    applyPositions();
  }
  let lastMode;
  ui.mode = (nextCar, nextRiding, nextPrompt, nextIndoors = false, nextSwimming = false, nextWet = false, nextFerry = false) => {
    const nextMode = nextCar ? 'drive' : 'foot';
    if (mode !== nextMode) releaseAll();
    car = nextCar; riding = nextRiding; prompt = nextPrompt; indoors = nextIndoors; swimming = nextSwimming; wet = nextWet; ferry = nextFerry; mode = nextMode;
    highlightToggles();
    const state = [mode, !!car?.auto, car?.type.id, !!riding, !!prompt, indoors, swimming, wet, ferry].join('|');
    if (state === lastMode) return;
    lastMode = state;
    controls.bAuto.textContent = car?.auto ? 'FSD ✓' : 'FSD';
    controls.bUse.textContent = car ? '下车' : '互动';
    showControls();
  };
}
