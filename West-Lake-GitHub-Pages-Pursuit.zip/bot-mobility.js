import { ROADS, groundY, makeStrip, pointAt } from './geo.js';

const ROAD_STEP = 10, LINK_RANGE = 14.5, MAX_CAR_WALK = 110;
const LANE_OFFSETS = [0, -2.7, 2.7];
const PARK = { thr: 0, steer: 0, brake: true, parked: true };
const DOORS = [[1.9, 0.65], [-1.9, 0.65], [1.9, -0.8], [-1.9, -0.8]];
const EXIT_OFFSETS = [[2.7, 0], [-2.7, 0], [0, -3.1], [0, 3.1]];
const DISTRICTS = Object.values(ROADS).map(([points]) => points).concat([
  [[-1904, -2956], [-1900, -3010], [-1900, -3072]],
  [[-2030, -3078], [-1780, -3078]],
]);
const angle = (radians) => Math.atan2(Math.sin(radians), Math.cos(radians));
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

function buildRoadNetwork(roadClear) {
  const nodes = [], buckets = new Map();
  const key = (i, j) => i * 100003 + j;
  const open = (x, z) => roadClear(x, z, groundY(x, z) + 0.08);
  function clear(a, b) {
    const length = distance(a, b);
    const count = Math.ceil(length / 2.4);
    const sideX = length ? (a.z - b.z) / length * 0.42 : 0;
    const sideZ = length ? (b.x - a.x) / length * 0.42 : 0;
    for (let i = 1; i <= count; i++) {
      const t = i / count, x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t;
      if (!open(x, z) || !open(x - sideX, z - sideZ) || !open(x + sideX, z + sideZ)) return false;
    }
    return true;
  }
  for (const points of DISTRICTS) {
    const road = makeStrip(points, 0), count = Math.ceil(road.len / ROAD_STEP);
    for (let i = 0; i <= count; i++) {
      const [x, z, dx, dz] = pointAt(road, road.len * i / count);
      for (const offset of LANE_OFFSETS) {
        const node = { x: x - dz * offset, z: z + dx * offset, links: [] };
        if (!open(node.x, node.z)) continue;
        const a = Math.floor(node.x / LINK_RANGE), b = Math.floor(node.z / LINK_RANGE);
        for (let di = -1; di <= 1; di++) for (let dj = -1; dj <= 1; dj++) {
          for (const other of buckets.get(key(a + di, b + dj)) || []) {
            const gap = distance(node, other);
            if (gap < 0.4 || gap > LINK_RANGE || !clear(node, other)) continue;
            node.links.push({ node: other, gap });
            other.links.push({ node, gap });
          }
        }
        const cell = key(a, b);
        if (!buckets.has(cell)) buckets.set(cell, []);
        buckets.get(cell).push(node);
        nodes.push(node);
      }
    }
  }

  return function plan(car, goal) {
    const origin = car.pos, trip = distance(origin, goal);
    let target = null, targetGap = Infinity;
    for (const node of nodes) {
      const gap = distance(node, goal);
      if (node.links.length && gap < targetGap) { target = node; targetGap = gap; }
    }
    if (!target || distance(target, goal) > Math.max(250, trip * 0.55)) return null;
    const queue = [], records = new Map();
    for (const node of nodes) {
      const gap = distance(origin, node);
      if (gap > 44 || !node.links.length || !clear(origin, node)) continue;
      const turn = gap < 2 ? 0 : Math.abs(angle(Math.atan2(origin.x - node.x, origin.z - node.z) - car.heading));
      const cost = gap + turn * 12;
      const entry = { node, cost, score: cost + distance(node, target), prev: null };
      queue.push(entry); records.set(node, entry);
    }
    for (let visited = 0; queue.length && visited < 2400; visited++) {
      let best = 0;
      for (let i = 1; i < queue.length; i++) if (queue[i].score < queue[best].score) best = i;
      const [current] = queue.splice(best, 1);
      if (records.get(current.node) !== current) continue;
      if (current.node === target) {
        if (current.cost < 90 || current.cost > trip * 2.8 + 300) return null;
        const path = [];
        for (let entry = current; entry; entry = entry.prev) path.push(entry.node);
        return path.reverse();
      }
      for (const { node, gap } of current.node.links) {
        const cost = current.cost + gap;
        if (records.get(node)?.cost <= cost) continue;
        const next = { node, cost, score: cost + distance(node, target), prev: current };
        records.set(node, next); queue.push(next);
      }
    }
    return null;
  };
}

function offset(car, side, forward) {
  const x = car.pos.x + Math.cos(car.heading) * side - Math.sin(car.heading) * forward;
  const z = car.pos.z - Math.sin(car.heading) * side - Math.cos(car.heading) * forward;
  return { x, y: groundY(x, z), z };
}

function control(ride, dt) {
  const { car, path } = ride, p = car.pos, speed = Math.abs(car.v);
  let goal = path[ride.index];
  if (ride.reverse && ride.index === ride.reverseAt && distance(p, goal) > 6) ride.reverse = false;
  while (ride.index < path.length - 1 && distance(p, goal) < 4.1) goal = path[++ride.index];
  const gap = distance(p, goal);
  if (ride.index > ride.progressIndex || gap < ride.progressGap - 0.8) {
    ride.stalled = 0; ride.progressIndex = ride.index; ride.progressGap = gap;
  } else ride.stalled += dt;
  if (ride.stalled > 8) { ride.phase = 'failed'; return PARK; }

  const last = ride.index === path.length - 1;
  if (last && gap < 3.5 && speed < 0.7) { ride.phase = 'arrived'; return PARK; }
  const heading = Math.atan2(p.x - goal.x, p.z - goal.z);
  const error = angle(heading - car.heading);
  if (!ride.reverse && speed < 1.3 && Math.abs(error) > 2.45 && ride.reverseAt !== ride.index) {
    ride.reverse = true; ride.reverseAt = ride.index;
  }
  if (ride.reverse && (ride.index > ride.reverseAt || Math.abs(error) < 1.45)) ride.reverse = false;
  const steering = ride.reverse ? -angle(error - Math.PI) : error;
  let desired = ride.reverse ? 3.3 : 12 / (1 + Math.abs(steering) * 1.7);
  // Brake before switching direction so reverse manoeuvres have a clear end.
  const incompatible = ride.reverse ? car.v > 0.7 : car.v < -0.7;
  if (incompatible) return { thr: 0, steer: 0, serviceBrake: 1 };
  if (last) desired = Math.min(desired, Math.sqrt(Math.max(0, gap - 2.4) * 5));
  else {
    const next = path[ride.index + 1];
    const corner = Math.abs(angle(Math.atan2(goal.x - next.x, goal.z - next.z) - heading));
    if (corner > 0.5) desired = Math.min(desired, 4 + gap * 0.45);
  }
  const delta = desired - speed;
  return {
    thr: clamp(delta * 0.24, 0, 0.75) * (ride.reverse ? -1 : 1),
    steer: clamp(steering * 2.5, -1, 1),
    serviceBrake: clamp(-delta * 0.4, 0, 1),
  };
}

export function createBotMobility({ cars, blocked, playerDriving }) {
  const rides = new Map();
  let plan;
  const clearExit = (point) => !blocked(point.x, point.y, point.z);
  const markSeated = (bot, ride) => {
    bot.carRide = ride;
    if (bot.g) bot.g.visible = !ride && bot.alive;
    bot.path = null;
    bot.routeIn = 0;
  };
  const leaveSeat = (ride, bot) => {
    ride.riders.delete(bot);
    markSeated(bot, null);
  };
  function approach(ride, slot = 0) {
    for (let i = 0; i < DOORS.length; i++) {
      const [side, forward] = DOORS[(i + slot) % DOORS.length];
      const point = offset(ride.car, side, forward);
      if (clearExit(point)) return point;
    }
    for (const [side, forward] of EXIT_OFFSETS) {
      const point = offset(ride.car, side, forward);
      if (clearExit(point)) return point;
    }
    return null;
  }
  function release(ride) {
    if (ride.riders.size || rides.get(ride.team) !== ride) return false;
    ride.car.aiRide = null; ride.car.aiInput = null;
    rides.delete(ride.team);
    return true;
  }
  return {
    claim(team, origin, goal) {
      if (rides.has(team) || distance(origin, goal) < 240) return null;
      const human = playerDriving?.();
      const candidates = cars.list.filter((car) => car !== human && !car.aiRide && car.visualReady &&
        Math.abs(car.v) < 0.5 && Math.abs(car.pos.y - origin.y) < 4 && distance(car.pos, origin) < MAX_CAR_WALK);
      candidates.sort((a, b) => distance(a.pos, origin) - distance(b.pos, origin));
      for (const car of candidates.slice(0, 3)) {
        if (!approach({ car })) continue;
        plan ??= buildRoadNetwork(cars.roadClear);
        const path = plan(car, goal);
        if (!path) continue;
        const ride = { team, car, path, phase: 'boarding', riders: new Set(), index: 0, waiting: 0, stalled: 0,
          progressIndex: 0, progressGap: Infinity, reverse: false, reverseAt: -1 };
        rides.set(team, ride); car.aiRide = ride;
        return ride;
      }
      return null;
    },
    approach,
    board(ride, bot) {
      const door = approach(ride, bot.slot);
      if (ride.phase !== 'boarding' || ride.riders.size >= 4 || !door || distance(bot.pos, door) > 2.1 ||
          Math.abs(bot.pos.y - door.y) > 1.8 || !bot.alive || bot.carRide) return false;
      ride.riders.add(bot);
      markSeated(bot, ride);
      return true;
    },
    depart(ride) {
      if (ride.phase !== 'boarding' || !ride.riders.size) return false;
      ride.phase = 'driving';
      return true;
    },
    update(dt) {
      for (const ride of rides.values()) {
        if (ride.phase === 'boarding' && (ride.waiting += dt) >= 25) ride.phase = ride.riders.size ? 'driving' : 'failed';
        ride.car.aiInput = ride.phase === 'driving' ? control(ride, dt) : PARK;
      }
    },
    sync(ride) {
      for (const bot of ride.riders) {
        if (!bot.alive) { leaveSeat(ride, bot); continue; }
        const point = offset(ride.car, bot.slot % 2 ? -0.43 : 0.43, bot.slot < 2 ? 0.35 : -0.75);
        bot.pos.set(point.x, ride.car.pos.y, point.z);
        bot.vel.set(ride.car.vx, 0, ride.car.vz);
      }
    },
    disembark(ride, bot) {
      if (!ride.riders.has(bot) || Math.abs(ride.car.v) > 1.2) return false;
      const point = approach(ride, bot.slot);
      if (!point) return false;
      bot.pos.set(point.x, point.y, point.z); bot.vel.set(0, 0, 0);
      leaveSeat(ride, bot);
      return true;
    },
    release,
    reset() {
      for (const ride of rides.values()) {
        for (const bot of ride.riders) leaveSeat(ride, bot);
        release(ride);
      }
    },
  };
}
