// Sky, sun, lake water and the hills that ring the lake on its south, west and north sides (the east is the city).
import * as THREE from 'three';
import { Sky } from 'three/addons/objects/Sky.js';
import { Water } from 'three/addons/objects/Water.js';
import { fbm, waterNormals } from './mats.js';
import { POI } from './geo.js';

export const SUN = new THREE.Vector3(-0.5, 0.62, -0.6).normalize(); // mid-afternoon sun in the south-west
export const FOG = 0.00021, FOG_COLOR = new THREE.Color(0.62, 0.69, 0.76);

export function buildEnv(scene, renderer) {
  scene.fog = new THREE.FogExp2(FOG_COLOR, FOG);
  const sky = new Sky(); sky.scale.setScalar(8000);
  const su = sky.material.uniforms;
  su.turbidity.value = 3.2; su.rayleigh.value = 1.1; su.mieCoefficient.value = 0.004; su.mieDirectionalG.value = 0.86; su.sunPosition.value.copy(SUN);
  su.cloudCoverage.value = 0.3; su.cloudDensity.value = 0.45; su.cloudElevation.value = 0.5;
  const skyScene = new THREE.Scene(); skyScene.add(sky);
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(skyScene, 0, 0.1, 20000).texture; pm.dispose(); // image-based lighting straight from the sky
  scene.environmentIntensity = 0.65; scene.add(sky);

  const sun = new THREE.DirectionalLight(0xffeccf, 4.4);
  sun.castShadow = true; sun.shadow.mapSize.set(4096, 4096);
  const sc = sun.shadow.camera; sc.left = sc.bottom = -90; sc.right = sc.top = 90; sc.near = 1; sc.far = 520;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.06;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(0xcfdcf0, 0x57503f, 0.55));

  const water = new Water(new THREE.PlaneGeometry(24000, 24000), {
    textureWidth: 1024, textureHeight: 1024, waterNormals: waterNormals(), sunDirection: SUN, sunColor: 0xfff4e0, waterColor: 0x1d4a44, distortionScale: 2.2, fog: true,
  });
  water.rotation.x = -Math.PI / 2; water.material.uniforms.size.value = 5; scene.add(water);

  // three ranks of hills: Nanshan in the south, round the west, to Baoshi and Geling in the north
  const [cx0, cz0] = POI.lakeCentre;
  function ridge(radius, a0, a1, base, amp, hex, seed, freq) {
    const N = 420, pos = [], idx = [];
    for (let i = 0; i <= N; i++) {
      const t = i / N, a = a0 + (a1 - a0) * t, edge = Math.min(1, Math.min(t, 1 - t) * 9);
      const h = (base + amp * (fbm(t, 0.3, freq, 1, 5, seed) - 0.3) * 1.6) * edge, cx = Math.cos(a), cz = Math.sin(a);
      for (const [dr, k] of [[-2.4, 0], [-1.3, 0.55], [-0.5, 0.9], [0, 1], [1.2, 0]]) pos.push(cx0 + cx * (radius + dr * h), h * k - 0.5, cz0 + cz * (radius + dr * h));
      if (i < N) for (let j = 0; j < 4; j++) { const p = i * 5 + j; idx.push(p, p + 5, p + 1, p + 1, p + 5, p + 6); }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
    scene.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: hex, roughness: 1, side: THREE.DoubleSide })));
  }
  ridge(2400, 2.62, 6.42, 60, 80, 0x243b1e, 311, 30);
  ridge(3050, 2.5, 6.5, 130, 140, 0x2a4224, 321, 22);
  ridge(3900, 2.4, 6.6, 210, 220, 0x30492b, 331, 14);

  return {
    sun, water, sky,
    update(t, dt, focus) {
      water.material.uniforms.time.value += dt * 0.7; su.time.value = t;
      const fx = Math.round(focus.x / 4) * 4, fz = Math.round(focus.z / 4) * 4; // snap so shadow edges do not swim
      sun.target.position.set(fx, 0, fz); sun.position.set(fx, 0, fz).addScaledVector(SUN, 260);
    },
  };
}
