// Reconstructed procedural streetscape. The glass pavilion fits the existing
// Hubin map footprint and is an artistic interpretation, not a survey.
import * as THREE from 'three';
import { BLOCKS, LAND_Y as Y, ROADS, makeStrip, pointAt, walkable } from './geo.js';

export function buildStreet(ctx) {
  const { scene, M, add, box, inBuilding } = ctx;
  const [, x0, x1, z0, z1] = BLOCKS.find(([name]) => name.startsWith('Apple'));
  const x = (x0 + x1) / 2, z = (z0 + z1) / 2, w = x1 - x0 - 1, d = z1 - z0 - 1;
  const h = 10.8, frame = new THREE.MeshStandardMaterial({ color: 0xaeb8b9, metalness: 0.55, roughness: 0.38 });
  const roof = new THREE.MeshStandardMaterial({ color: 0xd2dedc, metalness: 0.25, roughness: 0.38 });
  const glazing = new THREE.MeshStandardMaterial({ color: 0x83bdc7, metalness: 0.14, roughness: 0.15, transparent: true, opacity: 0.25, depthWrite: false, side: THREE.DoubleSide });
  const glowing = new THREE.MeshStandardMaterial({ color: 0xffe6b5, emissive: 0xffd4a2, emissiveIntensity: 1.65 });
  const floor = new THREE.MeshStandardMaterial({ color: 0x68757a, roughness: 0.62, metalness: 0.15 });

  box(w + 0.6, 0.24, d + 0.6, floor, x, Y + 0.09, z, { collide: true });
  box(w + 1.2, 0.38, d + 1.2, roof, x, Y + h, z);
  box(w - 0.7, 0.14, d - 0.7, floor, x, Y + h - 0.21, z);
  // Window bays open at the middle of the two Z façades so the pavilion is walkable.
  const pane = (pw, ph, px, py, pz, ry) => {
    const g = add(new THREE.PlaneGeometry(pw, ph), glazing, px, py, pz, { ry, shadow: false, collide: true });
    ctx.noAO.push(g);
  };
  for (const sign of [-1, 1]) {
    const faceZ = z + sign * d / 2, faceX = x + sign * w / 2;
    const gap = 3.8, bay = (w - gap) / 8, sideBay = d / 8;
    for (const flank of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const px = x + flank * (gap / 2 + (i + 0.5) * bay);
        pane(bay + 0.03, h - 0.7, px, Y + h / 2, faceZ, 0);
        box(0.16, h - 0.3, 0.19, frame, px + flank * bay / 2, Y + h / 2, faceZ);
      }
      box(0.2, h - 0.3, 0.19, frame, x + flank * gap / 2, Y + h / 2, faceZ);
    }
    pane(gap, h - 3.3, x, Y + (h + 3) / 2, faceZ, 0);
    for (let i = 0; i < 8; i++) {
      const pz = z - d / 2 + (i + 0.5) * sideBay;
      pane(sideBay + 0.03, h - 0.7, faceX, Y + h / 2, pz, Math.PI / 2);
      box(0.19, h - 0.3, 0.16, frame, faceX, Y + h / 2, pz + sideBay / 2);
    }
    box(w, 0.15, 0.16, frame, x, Y + 3.05, faceZ);
    box(0.16, 0.15, d, frame, faceX, Y + 3.05, z);
  }
  for (const dz of [-d * 0.31, 0, d * 0.31]) {
    box(w * 0.78, 0.07, 0.22, glowing, x, Y + h - 0.34, z + dz, { shadow: false });
    for (const dx of [-w * 0.23, w * 0.23]) {
      box(2.8, 0.09, 1.15, roof, x + dx, Y + 1.06, z + dz);
      box(2.35, 0.8, 0.73, M.wood, x + dx, Y + 0.63, z + dz, { collide: true });
      box(1.35, 0.05, 0.18, glowing, x + dx, Y + 1.13, z + dz, { shadow: false });
    }
  }

  // Lightweight public-space furniture on the pedestrian lanes, clear of
  // buildings and away from the road centre and game spawn.
  const postMat = new THREE.MeshStandardMaterial({ color: 0x343d42, metalness: 0.5, roughness: 0.5 });
  const dummy = new THREE.Object3D();
  const rows = [[], [], [], []];
  const push = (i, a, b, c, ry) => rows[i].push([a, b, c, ry]);
  const layouts = [['东坡路', 43], ['学士路', 55], ['仁和路', 46]];
  for (const [name, spacing] of layouts) {
    const [points, width] = ROADS[name], strip = makeStrip(points, width / 2);
    for (let s = 36; s < strip.len - 30; s += spacing) {
      const [px, pz, dx, dz] = pointAt(strip, s);
      const side = Math.round(s / spacing) % 2 ? -1 : 1;
      const sx = px - dz * (width / 2 + 2.35) * side, sz = pz + dx * (width / 2 + 2.35) * side;
      if (!walkable(sx, sz) || inBuilding(sx, sz) || Math.hypot(sx - x, sz - z) < 24) continue;
      const yaw = Math.atan2(-dz, dx);
      push(0, sx, Y + 0.5, sz, yaw);
      for (const t of [-0.78, 0.78]) push(1, sx + t * dx, Y + 0.23, sz + t * dz, yaw);
      const lx = sx + 3.0 * dx, lz = sz + 3.0 * dz;
      if (walkable(lx, lz) && !inBuilding(lx, lz)) {
        push(2, lx, Y + 1.7, lz, 0);
        push(3, lx, Y + 3.44, lz, 0);
        ctx.lamps.push([lx, lz]);
      }
    }
  }
  for (const [i, geo, mat] of [
    [0, new THREE.BoxGeometry(2.2, 0.11, 0.48), M.wood],
    [1, new THREE.BoxGeometry(0.13, 0.46, 0.39), postMat],
    [2, new THREE.CylinderGeometry(0.045, 0.07, 3.4, 8), postMat],
    [3, new THREE.BoxGeometry(0.42, 0.12, 0.23), glowing],
  ]) {
    if (!rows[i].length) { geo.dispose(); continue; }
    const meshes = new THREE.InstancedMesh(geo, mat, rows[i].length);
    rows[i].forEach(([px, py, pz, ry], j) => {
      dummy.position.set(px, py, pz); dummy.rotation.y = ry; dummy.updateMatrix(); meshes.setMatrixAt(j, dummy.matrix);
    });
    meshes.receiveShadow = true;
    scene.add(meshes);
  }
}
