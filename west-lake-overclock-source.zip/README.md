# West Lake Overclock · 西湖超频

杭州西湖的 3D 浏览器游戏。桌面用键盘和鼠标；手机和平板进入游戏后会显示触屏按钮。浏览器需支持 WebGL 2。

## 本地运行

需要 Node.js 22.12 或更新版本。

```sh
npm ci
npm run dev
```

用 `npm run build` 生成 `dist/`，再用 `npm run preview` 预览。游戏文件使用相对路径，同一份产物可以部署在域名根目录或 GitHub 项目的子目录。

## 发布

- **GitHub Pages**：将构建后的 `dist/` 内容放入仓库的 `docs/`（保留 `.nojekyll`），在 **Settings → Pages** 选择 **Deploy from a branch → main → /docs**。后续更新时，重新构建并替换 `docs/` 内容。
- **Cloudflare Pages**：连接此 GitHub 仓库，生产分支选 `main`，构建命令填 `npm run build`，构建输出目录填 `dist`。

## 数据与依赖

- 地图数据 © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright)，依 [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/) 提供。项目使用的修改后地图数据见 [geo.js](geo.js) 与 [hubin_data.js](hubin_data.js)。
- [Three.js](https://threejs.org/) 使用 MIT 许可证；见 [THREE-LICENSE.txt](public/THREE-LICENSE.txt)。
