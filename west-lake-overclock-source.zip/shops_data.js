// Fictional storefronts for the game. Placement uses the existing Hubin building
// outlines (© OpenStreetMap contributors, ODbL); these are not real business listings.
import { BUILDINGS } from './hubin_data.js';
import { ROADS, nearest } from './geo.js';

const names = [
  '岚岸咖啡', '桥影书房', '瓦灯茶铺', '湖风面包', '苔阶陶坊', '暮色唱片',
  '云埠花店', '青芜甜点', '雨巷修表', '白屿照相', '潮纹纸品', '檐铃杂货',
  '星渠冰室', '柳窗面馆', '初汀茶社', '松檐布铺', '拾光画框', '远岫香铺',
  '风荷汽水', '云岑书局', '灯船夜点', '石纹工坊', '浅湾果铺', '绢桥文具',
  '听雨旧物', '望汀早餐', '青埠花房', '月瓦手作', '水巷酥饼', '临窗咖啡',
  '南枝织物', '白波唱片', '渔灯面点', '桑影茶房', '纸船玩具', '浅滩果茶',
  '青镜银饰', '潮汐书架', '流云布店', '晚钟面馆', '西泠纸艺', '岸灯食堂',
  '雨舟画室', '荷塘糖水', '桥南鞋铺', '水纹陶器', '夜汀修理', '风铃花坊',
];
const roads = Object.values(ROADS).map(([pts]) => pts);
const candidates = [];
for (const [name, , , type, pts] of BUILDINGS) {
  if (name.includes('Apple') || /train_station|school|hospital|hotel|residential|apartments/.test(type)) continue;
  let best = null;
  for (let i = 0; i < pts.length; i += 2) {
    const j = (i + 2) % pts.length, dx = pts[j] - pts[i], dz = pts[j + 1] - pts[i + 1], l = Math.hypot(dx, dz);
    if (l < 8) continue;
    const x = (pts[i] + pts[j]) / 2 - dz / l * 0.9;
    const z = (pts[i + 1] + pts[j + 1]) / 2 + dx / l * 0.9;
    const distance = Math.min(...roads.map(road => nearest(road, null, x, z).d));
    const score = distance - Math.min(l, 18) * 0.22;
    if (!best || score < best.score) best = { x, z, score };
  }
  if (best) candidates.push(best);
}
candidates.sort((a, b) => a.score - b.score);
const selected = [];
for (const spot of candidates) {
  if (selected.length >= names.length) break;
  if (selected.some(other => Math.hypot(spot.x - other.x, spot.z - other.z) < 5)) continue;
  selected.push(spot);
}
export const SHOPS = selected.map(({ x, z }, i) => [names[i], 'fictional_shop', x, z]);
