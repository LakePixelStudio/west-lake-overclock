// AI battle royale: four teams of ten humanoid robots (the player is one of team 0) fight across the whole map inside a shrinking zone.
// Robots are built from capsules, spheres and a lathed torso (no boxes), with a procedural walk cycle and an aiming pose.
import * as THREE from 'three';
import { LAND_Y, RING, POI, groundY, walkable, makeStrip, nearest, pointAt, pipFlat } from './geo.js';

export const TEAMS = [{ name: 'GPU 队', short: 'GPU', color: 0x30d8ff }, { name: 'RAM 队', short: 'RAM', color: 0xffb000 }, { name: '火箭队', short: '火箭', color: 0xff4a3a }, { name: 'LLM 队', short: 'LLM', color: 0x62e08a }];
const SPAWNS = [[-18, 96], [600, -745], [-1560, -2700], [-2600, -695]];                                   // Hubin, Broken Bridge, Yanggongdi, Leifeng
const FINALS = [[-60, 200], [600, -745], [-2600, -695], [-1560, -2700], [-1283, -136]];                    // ring-side spots the last circle can close on
const STAGES = [4300, 2600, 1500, 800, 350, 120, 40];   // the lake fills the middle of the map, so the zone always closes on a shore point, never the centre

export function createBattle(o) { // o: {scene, fx, world, M, player, blocked, burst, tracer, boom, hurtPlayer, note, sfx, camera}
  const { scene, world, player } = o, group = new THREE.Group(); scene.add(group);
  const ring = makeStrip([...RING, RING[0]], 0), rand = (a, b) => a + Math.random() * (b - a);
  // ---- shared robot parts
  const shell = new THREE.MeshStandardMaterial({ color: 0xe6e8ea, roughness: 0.32, metalness: 0.15 }), joint = new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: 0.5, metalness: 0.6 });
  const cap = (r, l) => new THREE.CapsuleGeometry(r, l, 6, 14).translate(0, -l / 2 - r * 0.2, 0);                // hangs down from its pivot
  const G = { torso: new THREE.LatheGeometry([[0.0, -0.06], [0.12, -0.05], [0.135, 0.04], [0.16, 0.2], [0.19, 0.33], [0.18, 0.43], [0.1, 0.5], [0.055, 0.55], [0, 0.56]].map(([r, y]) => new THREE.Vector2(r, y)), 22).scale(1, 1, 0.72),
    pelvis: new THREE.SphereGeometry(0.15, 18, 12).scale(1.1, 0.75, 0.85), head: new THREE.SphereGeometry(0.108, 22, 16).scale(0.95, 1.1, 1),
    visor: new THREE.SphereGeometry(0.112, 22, 10, Math.PI * 0.18, Math.PI * 0.64, Math.PI * 0.32, Math.PI * 0.24).scale(0.95, 1.1, 1),
    upper: cap(0.05, 0.2), fore: cap(0.043, 0.2), hand: new THREE.SphereGeometry(0.05, 12, 10), thigh: cap(0.072, 0.28), shin: cap(0.055, 0.3),
    foot: new THREE.CapsuleGeometry(0.048, 0.13, 4, 10).rotateX(Math.PI / 2).translate(0, -0.4, 0.06), ball: new THREE.SphereGeometry(0.062, 12, 10),
    gun: new THREE.CapsuleGeometry(0.03, 0.34, 4, 10).rotateX(Math.PI / 2).translate(0, -0.34, 0.16), stripe: new THREE.CapsuleGeometry(0.012, 0.26, 3, 8).rotateX(Math.PI / 2).translate(0, -0.305, 0.16) };
  const accents = TEAMS.map((t) => new THREE.MeshStandardMaterial({ color: 0, emissive: t.color, emissiveIntensity: 2.2 }));
  function makeRobot(bot) {
    const g = new THREE.Group(), acc = accents[bot.team], P = {};
    const m = (geo, mat, parent, x = 0, y = 0, z = 0) => { const k = new THREE.Mesh(geo, mat); k.position.set(x, y, z); k.castShadow = true; k.userData.bot = bot; parent.add(k); return k; };
    const pivot = (parent, x, y, z) => { const p = new THREE.Group(); p.position.set(x, y, z); parent.add(p); return p; };
    const hips = pivot(g, 0, 0.93, 0); P.hips = hips; m(G.pelvis, joint, hips);
    m(G.torso, shell, hips, 0, 0.06, 0); m(G.head, shell, hips, 0, 0.75, 0); m(G.visor, acc, hips, 0, 0.75, 0).rotation.y = -Math.PI / 2;
    for (const s of [-1, 1]) {
      const sh = pivot(hips, s * 0.235, 0.5, 0), el = pivot(sh, 0, -0.29, 0); m(G.ball, joint, sh); m(G.upper, shell, sh); m(G.ball, joint, el).scale.setScalar(0.8); m(G.fore, shell, el); m(G.hand, joint, el, 0, -0.3, 0);
      const hp = pivot(hips, s * 0.1, -0.04, 0), kn = pivot(hp, 0, -0.42, 0); m(G.thigh, shell, hp); m(G.ball, joint, kn).scale.setScalar(0.95); m(G.shin, shell, kn); m(G.foot, joint, kn);
      P[s < 0 ? 'armL' : 'armR'] = sh; P[s < 0 ? 'elL' : 'elR'] = el; P[s < 0 ? 'legL' : 'legR'] = hp; P[s < 0 ? 'knL' : 'knR'] = kn;
      if (s > 0) { m(G.gun, joint, el); m(G.stripe, acc, el); }
    }
    group.add(g); bot.g = g; bot.P = P;
  }
  // ---- cover check without raycasts: walk the sight line through the collision grid
  function los(a, b) {
    const dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz), n = Math.ceil(d / 3);
    for (let i = 1; i < n; i++) { const t = i / n, x = a.x + dx * t, z = a.z + dz * t, y = a.y + 1.4 + (b.y - a.y) * t, c = world.near(x, z);
      for (const p of c.polys) if (y < p.h + LAND_Y && pipFlat(p.pts, x, z)) return false;
      for (const bx of c.boxes) if (y < bx.max.y && y > bx.min.y && x > bx.min.x && x < bx.max.x && z > bx.min.z && z < bx.max.z) return false; }
    return true;
  }
  // ---- entities: the player plus 39 robots
  const me = { isPlayer: true, team: 0, pos: player.pos, vel: player.vel, kills: 0, get alive() { return player.hp > 0; } }, bots = [], ents = [me];
  for (let team = 0; team < 4; team++) for (let i = team === 0 ? 1 : 0; i < 10; i++) { const b = { team, pos: new THREE.Vector3(), vel: new THREE.Vector3(), yaw: 0, hp: 100, alive: true, kills: 0, think: Math.random() * 0.3, cool: 1, phase: Math.random() * 6, target: null, goal: null, stuck: 0, last: new THREE.Vector3(), dead: 0, side: Math.random() < 0.5 ? 1 : -1 };
    makeRobot(b); bots.push(b); ents.push(b); }
  const zone = { x: 0, z: 0, r: 0, stage: 0, t: 0, from: null, to: null, fin: null, shrinking: false };
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 128, 1, true), new THREE.MeshBasicMaterial({ color: 0x3aa0ff, transparent: true, opacity: 0.13, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
  o.fx.add(wall);
  const rockets = [], rGeo = new THREE.CapsuleGeometry(0.07, 0.6, 4, 10).rotateX(Math.PI / 2), rMat = new THREE.MeshStandardMaterial({ color: 0xf2f2f0, roughness: 0.35 }), flame = new THREE.MeshBasicMaterial({ color: new THREE.Color(8, 4, 1), fog: false });
  let over = null;

  function reset() {
    over = null;
    for (const b of bots) { let x, z, k = 0; do { x = SPAWNS[b.team][0] + rand(-28, 28); z = SPAWNS[b.team][1] + rand(-28, 28); } while (o.blocked(x, LAND_Y, z) && ++k < 60);
      b.pos.set(x, groundY(x, z), z); b.hp = 100; b.alive = true; b.kills = 0; b.target = b.goal = null; b.dead = 0; b.g.visible = true; b.g.rotation.set(0, 0, 0); b.g.position.copy(b.pos); b.last.copy(b.pos); }
    me.kills = 0; const f = FINALS[Math.floor(Math.random() * FINALS.length)];
    Object.assign(zone, { x: f[0], z: f[1], r: STAGES[0], stage: 0, t: 120, shrinking: false, fin: f });
    for (const r of rockets) scene.remove(r.m); rockets.length = 0;
  }
  function damage(e, dmg, by) {
    if (!e.alive || (by && by.team === e.team)) return false;
    if (e.isPlayer) { o.hurtPlayer(dmg); if (player.hp <= 0 && by) by.kills++; return true; }
    e.hp -= dmg; if (e.hp > 0) return true;
    e.alive = false; e.dead = 0.01; if (by) { by.kills++; if (by.isPlayer) o.note(`击倒 ${TEAMS[e.team].name} 的机器人 · 你已击倒 ${by.kills}`); }
    return true;
  }
  function explode(p, by) { o.boom(p); for (const e of ents) { const d = e.pos.distanceTo(p); if (d < 8) damage(e, 130 * (1 - d / 9), by); } }
  function fireRocket(origin, dir, by) { const m = new THREE.Mesh(rGeo, rMat), fl = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.5, 8).rotateX(-Math.PI / 2).translate(0, 0, -0.55), flame); m.add(fl);
    m.position.copy(origin); m.lookAt(origin.clone().add(dir)); scene.add(m); rockets.push({ m, vel: dir.clone().multiplyScalar(55), by, life: 6 }); }

  const tmp = new THREE.Vector3(), from = new THREE.Vector3(), to = new THREE.Vector3();
  function steer(b, gx, gz) { // -> unit direction toward a goal, round the lake when the straight line crosses water
    let dx = gx - b.pos.x, dz = gz - b.pos.z, d = Math.hypot(dx, dz) || 1, clear = d < 700;   // the whole line must be dry land, or they dither at the shore
    for (let s = 12; clear && s < d; s += 12) if (!walkable(b.pos.x + dx / d * s, b.pos.z + dz / d * s)) { clear = false; break; }
    if (!clear) { const a = nearest(ring.pts, ring.cum, b.pos.x, b.pos.z), g = nearest(ring.pts, ring.cum, gx, gz); let fwd = (g.s - a.s + ring.len) % ring.len; const dirn = fwd < ring.len / 2 ? 1 : -1;
      const [tx, tz] = pointAt(ring, (a.s + dirn * 16 + ring.len) % ring.len); dx = tx - b.pos.x; dz = tz - b.pos.z; d = Math.hypot(dx, dz) || 1; }
    return [dx / d, dz / d];
  }
  function update(dt, t) {
    // ---- zone
    zone.t -= dt;
    if (zone.t <= 0 && zone.stage < STAGES.length - 1) {
      if (!zone.shrinking) { zone.shrinking = true; zone.t = zone.dur = zone.stage ? 80 : 120; zone.from = { x: zone.x, z: zone.z, r: zone.r }; zone.to = { x: zone.fin[0], z: zone.fin[1], r: STAGES[zone.stage + 1] }; o.note('安全区正在缩小'); }
      else { zone.shrinking = false; zone.stage++; zone.t = 60; }
    }
    if (zone.shrinking) { const k = 1 - Math.max(0, zone.t) / zone.dur; zone.x = zone.from.x + (zone.to.x - zone.from.x) * k; zone.z = zone.from.z + (zone.to.z - zone.from.z) * k; zone.r = zone.from.r + (zone.to.r - zone.from.r) * k; }
    wall.position.set(zone.x, 100, zone.z); wall.scale.set(zone.r, 400, zone.r);
    for (const e of ents) if (e.alive && Math.hypot(e.pos.x - zone.x, e.pos.z - zone.z) > zone.r) { if (e.isPlayer) o.hurtPlayer((0.4 + zone.stage * 0.6) * dt, true); else { e.hp -= (0.4 + zone.stage * 0.6) * dt; if (e.hp <= 0) { e.alive = false; e.dead = 0.01; } } }

    // ---- robots
    const cam = o.camera.position;
    for (const b of bots) {
      const P = b.P;
      if (!b.alive) { if (b.dead > 0 && b.dead < 1) { b.dead = Math.min(1, b.dead + dt * 2.2); b.g.rotation.x = -b.dead * 1.5; b.g.position.y = b.pos.y + b.dead * 0.12; } continue; }
      if ((b.think -= dt) <= 0) { b.think = 0.3;
        let best = null, bd = 90; for (const e of ents) if (e.alive && e.team !== b.team) { const d = e.pos.distanceTo(b.pos); if (d < bd && los(b.pos, e.pos)) { bd = d; best = e; } }
        b.target = best;
        if (!best) { const dz = Math.hypot(b.pos.x - zone.x, b.pos.z - zone.z); if (dz > zone.r * 0.7) b.goal = [zone.x, zone.z]; else { let ne = null, nd = 1e9; for (const e of ents) if (e.alive && e.team !== b.team) { const d = e.pos.distanceTo(b.pos); if (d < nd) { nd = d; ne = e; } } b.goal = ne ? [ne.pos.x, ne.pos.z] : null; } }
        if (b.pos.distanceTo(b.last) < 0.6) b.stuck = 1.2; b.last.copy(b.pos);
      }
      let mx = 0, mz = 0, speed = 0;
      if (b.target && b.target.alive) { const e = b.target, dx = e.pos.x - b.pos.x, dz = e.pos.z - b.pos.z, d = Math.hypot(dx, dz) || 1; b.yaw = Math.atan2(dx, dz);
        if (d > 26) { mx = dx / d; mz = dz / d; speed = 4.6; } else if (d < 9) { mx = -dx / d; mz = -dz / d; speed = 3; } else { mx = -dz / d * b.side; mz = dx / d * b.side; speed = 2.2; if (Math.random() < dt * 0.4) b.side *= -1; }
        if ((b.cool -= dt) <= 0) { b.cool = rand(0.22, 0.5);
          from.set(b.pos.x + dx / d * 0.5, b.pos.y + 1.35, b.pos.z + dz / d * 0.5); const hit = Math.random() < Math.max(0.08, 0.62 - d / 130) * (e.vel && e.vel.length() > 5 ? 0.55 : 1);
          to.set(e.pos.x + (hit ? 0 : rand(-1.5, 1.5)), e.pos.y + 1.2 + (hit ? 0 : rand(-0.6, 1.4)), e.pos.z + (hit ? 0 : rand(-1.5, 1.5)));
          if (from.distanceTo(cam) < 260) { o.tracer(from, to, TEAMS[b.team].color); if (from.distanceTo(cam) < 90) o.sfx.botShot(); }
          if (hit) damage(e, 8, b); } }
      else if (b.goal) { [mx, mz] = steer(b, b.goal[0], b.goal[1]); speed = 9.5; b.yaw = Math.atan2(mx, mz); }   // robots run fast between fights: the lake is 10 km round
      if (b.stuck > 0) { b.stuck -= dt; const a = Math.atan2(mx, mz) + b.side * 1.3; mx = Math.sin(a); mz = Math.cos(a); }
      if (speed) { const nx = b.pos.x + mx * speed * dt, nz = b.pos.z + mz * speed * dt;
        if (!o.blocked(nx, b.pos.y, nz)) { b.pos.x = nx; b.pos.z = nz; } else if (!o.blocked(nx, b.pos.y, b.pos.z)) b.pos.x = nx; else if (!o.blocked(b.pos.x, b.pos.y, nz)) b.pos.z = nz; else speed = 0;
        b.pos.y = groundY(b.pos.x, b.pos.z); }
      // pose
      b.phase += speed * dt * 2.1; const sw = Math.sin(b.phase) * Math.min(1, speed / 4) * 0.75, aiming = !!b.target;
      b.g.position.set(b.pos.x, b.pos.y + Math.abs(Math.cos(b.phase)) * 0.025 * Math.min(1, speed), b.pos.z);
      let dy = b.yaw - b.g.rotation.y; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); b.g.rotation.y += dy * Math.min(1, dt * 9);
      P.legL.rotation.x = -sw; P.legR.rotation.x = sw; P.knL.rotation.x = Math.max(0, sw) * 1.1 + 0.05; P.knR.rotation.x = Math.max(0, -sw) * 1.1 + 0.05;
      P.armL.rotation.x = sw * 0.8; P.elL.rotation.x = -0.25 - Math.abs(sw) * 0.4; P.armR.rotation.x += ((aiming ? -1.35 : -sw * 0.8) - P.armR.rotation.x) * Math.min(1, dt * 10); P.elR.rotation.x = aiming ? -0.15 : -0.3;
      P.hips.rotation.x = Math.min(0.2, speed * 0.03);
    }
    // ---- rockets
    for (let i = rockets.length - 1; i >= 0; i--) { const r = rockets[i], p = r.m.position; p.addScaledVector(r.vel, dt); r.life -= dt; r.vel.y -= 2 * dt; o.burst(p, tmp.set(0, 0, 0), 2, 1.2, 0.7, 0.7, 0.7);
      const c = world.near(p.x, p.z); let hit = r.life <= 0 || p.y < (walkable(p.x, p.z) ? groundY(p.x, p.z) : 0) || c.polys.some((q) => p.y < q.h + LAND_Y && pipFlat(q.pts, p.x, p.z)) || c.boxes.some((bx) => bx.containsPoint(p));
      for (const e of ents) if (e.alive && e.team !== r.by.team && e.pos.distanceTo(p) < 1.8) hit = true;
      if (hit) { explode(p.clone(), r.by); scene.remove(r.m); rockets.splice(i, 1); } }
    // ---- outcome
    const alive = [0, 0, 0, 0]; for (const e of ents) if (e.alive) alive[e.team]++;
    if (!over) { const left = alive.filter((n) => n > 0).length; if (!me.alive) over = 'lose'; else if (left === 1) over = 'win'; }
    return alive;
  }
  reset();
  return { group, bots, ents, me, zone, update, reset, damage, explode, fireRocket, get over() { return over; },
    placing() { const order = TEAMS.map((_, i) => i).filter((i) => ents.some((e) => e.alive && e.team === i)).length; return order; } };
}
