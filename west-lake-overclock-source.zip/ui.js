// Touch controls for phones and tablets, and the map (corner minimap; M or a tap opens the full lake map).
import { WATER, GUSHAN, ISLETS, ROADS, RING, STRIPS, STATIONS, BLOCKS, POI, BOAT_ROUTE } from './geo.js';

const css = `
#map{position:fixed;right:18px;top:18px;width:190px;height:190px;border-radius:50%;border:2px solid rgba(255,255,255,.55);box-shadow:0 2px 12px rgba(0,0,0,.5);pointer-events:auto;cursor:pointer;background:#27402a}
#map.big{right:50%;top:50%;transform:translate(50%,-50%);width:min(86vmin,760px);height:min(86vmin,760px);border-radius:10px}
#touch{position:fixed;inset:0;display:none;touch-action:none;-webkit-user-select:none;user-select:none;--pad:5vw;--base:max(5vh,env(safe-area-inset-bottom));--small:clamp(49px,11vmin,76px);--large:clamp(64px,15vmin,104px);--gap:clamp(8px,1.5vmin,14px);--stick:clamp(100px,23vmin,150px)}
#touch.on{display:block}
#stick{position:absolute;left:var(--pad);bottom:var(--base);width:var(--stick);height:var(--stick);border-radius:50%;background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.4)}
#stick i{position:absolute;left:50%;top:50%;width:42%;height:42%;margin:-21%;border-radius:50%;background:rgba(255,255,255,.55)}
.tb{position:absolute;min-width:var(--small);height:var(--small);padding:0 7px;border-radius:999px;border:2px solid rgba(255,255,255,.55);background:rgba(10,14,20,.64);color:#fff;font:600 clamp(10px,2.3vmin,14px) "Segoe UI","Microsoft YaHei",sans-serif;letter-spacing:.02em}
.tb.act{background:rgba(255,176,0,.75);color:#111}.tb.hide{display:none}
#bGas,#bFire{right:var(--pad);bottom:var(--base);width:var(--large);height:var(--large);font-size:clamp(13px,3vmin,17px)}
#bBrake,#bJump{right:calc(var(--pad) + var(--large) + var(--gap));bottom:var(--base)}
#bDrift,#bAim{right:var(--pad);bottom:calc(var(--base) + var(--large) + var(--gap))}
#bAuto,#bSwap{right:calc(var(--pad) + var(--large) + var(--gap));bottom:calc(var(--base) + var(--small) + var(--gap))}
#bUse{right:var(--pad);bottom:calc(var(--base) + var(--large) + var(--small) + 2 * var(--gap))}
@media (pointer:coarse){
  #osd{top:12px;left:12px;font-size:10px;padding:6px 9px}
  #right,#left{bottom:auto;top:145px}
  #left{left:12px}#right{right:12px}
  .bar{width:min(120px,30vw)}.big{font-size:19px}#slots{font-size:9px}
  #map:not(.big){top:12px;right:12px;width:clamp(82px,19vmin,132px);height:clamp(82px,19vmin,132px)}
  #top{top:117px;left:8px;right:8px;font-size:10px;letter-spacing:.05em}
  #top,#slots{pointer-events:none}
}
@media (pointer:coarse) and (orientation:landscape){
  #top{top:13px;left:25%;right:25%}
  #left{top:137px}#right{top:75px;right:auto;left:25%;text-align:left}
}
`;

export function createUI({ keys, onLook, onUse, onSwap }) {
  document.head.appendChild(Object.assign(document.createElement('style'), { textContent: css }));
  const hud = document.getElementById('hud'), map = Object.assign(document.createElement('canvas'), { id: 'map', width: 760, height: 760 }); hud.appendChild(map);
  const touch = Object.assign(document.createElement('div'), { id: 'touch' }); document.body.appendChild(touch);
  touch.innerHTML = '<div id="stick"><i></i></div>' + [['bGas', '加速 GAS'], ['bBrake', 'BRAKE'], ['bDrift', '漂移 DRIFT'], ['bAuto', 'AUTO'], ['bFire', 'FIRE'], ['bJump', 'JUMP'], ['bAim', 'AIM'], ['bSwap', 'GPU'], ['bUse', 'E']].map(([id, t]) => `<button class="tb" id="${id}">${t}</button>`).join('');
  const $ = (id) => document.getElementById(id), ui = { touch: matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window, moveX: 0, moveY: 0, fire: false, aim: false, big: false, autoTap: false };
  if (ui.touch) touch.classList.add('on');

  // joystick: move on foot, steer when driving
  const stick = $('stick'), knob = stick.firstChild; let sid = null;
  const stickMove = (t) => { const r = stick.getBoundingClientRect(), reach = r.width * 0.4, dx = (t.clientX - r.left - r.width / 2) / reach, dy = (t.clientY - r.top - r.height / 2) / reach, l = Math.max(1, Math.hypot(dx, dy)); ui.moveX = dx / l; ui.moveY = -dy / l; knob.style.transform = `translate(${ui.moveX * r.width * 0.29}px,${-ui.moveY * r.height * 0.29}px)`; };
  stick.addEventListener('touchstart', (e) => { e.preventDefault(); sid = e.changedTouches[0].identifier; stickMove(e.changedTouches[0]); }, { passive: false });
  stick.addEventListener('touchmove', (e) => { e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === sid) stickMove(t); }, { passive: false });
  const stickEnd = (e) => { for (const t of e.changedTouches) if (t.identifier === sid) { sid = null; ui.moveX = ui.moveY = 0; knob.style.transform = ''; } };
  stick.addEventListener('touchend', stickEnd); stick.addEventListener('touchcancel', stickEnd);
  // drag anywhere else to look
  const looks = new Map();
  touch.addEventListener('touchstart', (e) => { for (const t of e.changedTouches) if (t.target === touch) looks.set(t.identifier, [t.clientX, t.clientY]); }, { passive: true });
  touch.addEventListener('touchmove', (e) => { e.preventDefault(); for (const t of e.changedTouches) { const p = looks.get(t.identifier); if (p) { onLook((t.clientX - p[0]) * 2.2, (t.clientY - p[1]) * 2.2); looks.set(t.identifier, [t.clientX, t.clientY]); } } }, { passive: false });
  const lookEnd = (e) => { for (const t of e.changedTouches) looks.delete(t.identifier); }; touch.addEventListener('touchend', lookEnd); touch.addEventListener('touchcancel', lookEnd);
  // buttons: hold = key down
  const hold = (id, down, up) => { const b = $(id); const d = (e) => { e.preventDefault(); e.stopPropagation(); b.classList.add('act'); down(); }, u = (e) => { e.preventDefault(); b.classList.remove('act'); up && up(); };
    b.addEventListener('touchstart', d, { passive: false }); b.addEventListener('touchend', u); b.addEventListener('touchcancel', u); b.addEventListener('mousedown', d); b.addEventListener('mouseup', u); };
  hold('bGas', () => (keys.KeyW = true), () => (keys.KeyW = false)); hold('bBrake', () => (keys.KeyS = true), () => (keys.KeyS = false)); hold('bDrift', () => (keys.Space = true), () => (keys.Space = false));
  hold('bJump', () => (keys.Space = true), () => (keys.Space = false)); hold('bFire', () => (ui.fire = true), () => (ui.fire = false)); hold('bAim', () => (ui.aim = !ui.aim));
  hold('bAuto', () => (ui.autoTap = true)); hold('bUse', onUse); hold('bSwap', onSwap);
  map.addEventListener('click', () => { ui.big = !ui.big; map.classList.toggle('big', ui.big); });
  addEventListener('keydown', (e) => { if (e.code === 'KeyM') map.click(); });

  // which buttons show depends on what the player is doing
  ui.mode = (driving, riding, auto, prompt) => {
    const show = (id, on) => $(id).classList.toggle('hide', !on);
    for (const id of ['bGas', 'bBrake', 'bDrift', 'bAuto']) show(id, driving); for (const id of ['bFire', 'bJump', 'bAim', 'bSwap']) show(id, !driving && !riding);
    $('bAuto').classList.toggle('act', !!auto); $('bAuto').textContent = auto ? '自动 AUTO ✓' : '自动 AUTO'; $('bAim').classList.toggle('act', ui.aim);
    $('bUse').textContent = driving ? '下车 EXIT' : prompt ? '上 / USE' : 'E'; show('bUse', driving || !!prompt || riding); stick.style.display = riding ? 'none' : '';
  };

  // ---- map
  const g = map.getContext('2d');
  ui.drawMap = (s) => { // s: {x, z, yaw, cars, ferry, zone, mates}
    const S = 760, span = ui.big ? 4700 : 950, cx = ui.big ? POI.lakeCentre[0] : s.x, cz = ui.big ? POI.lakeCentre[1] + 600 : s.z, k = S / span;
    const X = (z) => S / 2 + (z - cz) * k, Yp = (x) => S / 2 - (x - cx) * k;
    const path = (pts, close) => { g.beginPath(); pts.forEach(([x, z], i) => (i ? g.lineTo(X(z), Yp(x)) : g.moveTo(X(z), Yp(x)))); if (close) g.closePath(); };
    g.fillStyle = '#2f4a2c'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#3d4348'; g.fillRect(X(Math.max(cz - span, 230)), 0, S, S);                                         // city tint east of Hubin
    path(WATER, true); g.fillStyle = '#3f86a8'; g.fill();
    g.fillStyle = '#2f4a2c'; path(GUSHAN, true); g.fill(); for (const i of ISLETS) { g.beginPath(); g.arc(X(i.z), Yp(i.x), i.r * k, 0, 7); g.fill(); }
    g.lineCap = g.lineJoin = 'round';
    for (const st of STRIPS) { path(st.pts); g.strokeStyle = '#cfc7ae'; g.lineWidth = Math.max(2, st.half * 2 * k); g.stroke(); }
    for (const [pts, w] of Object.values(ROADS)) { path(pts); g.strokeStyle = '#e8e4d8'; g.lineWidth = Math.max(1.5, w * k); g.stroke(); }
    path([...RING, RING[0]]); g.strokeStyle = 'rgba(255,176,0,.9)'; g.lineWidth = ui.big ? 3 : 2; g.setLineDash([10, 8]); g.stroke(); g.setLineDash([]);   // the scenic ring
    path(BOAT_ROUTE); g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1.5; g.setLineDash([4, 6]); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#8b3a3a'; for (const [, x0, x1, z0, z1] of BLOCKS) g.fillRect(X(z0), Yp(x1), (z1 - z0) * k, (x1 - x0) * k);
    const fs = ui.big ? 17 : 22; g.font = `600 ${fs}px "Microsoft YaHei","Segoe UI",sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
    const label = (t, x, z, col = '#fff') => { g.fillStyle = 'rgba(0,0,0,.55)'; g.fillText(t, X(z) + 1, Yp(x) + 1); g.fillStyle = col; g.fillText(t, X(z), Yp(x)); };
    for (const st of STATIONS) { g.fillStyle = '#d8232a'; g.beginPath(); g.arc(X(st.z), Yp(st.x), ui.big ? 7 : 11, 0, 7); g.fill(); label('M ' + st.name, st.x + (ui.big ? 70 : 26), st.z, '#ffb3b3'); }
    for (const [t, p] of [['雷峰塔', POI.leifeng], ['保俶塔', POI.baochu], ['断桥', [569, -801]], ['平湖秋月', POI.pavilion], ['苏堤', [-1400, -2080]], ['白堤', [280, -1000]], ['in77', [-90, 250]], ['码头', [-56, 26]], ['码头', [-2412, -712]], ['孤山', [-230, -1700]], ['三潭印月', [-1680, -1340]]]) label(t, p[0], p[1], '#ffe9b0');
    if (ui.big) { label('钱江新城 →', -1300, cz + span / 2 - 260, '#ffe9b0'); g.font = '12px sans-serif'; g.fillStyle = 'rgba(255,255,255,.7)'; g.textAlign = 'left'; g.fillText('map data © OpenStreetMap contributors', 10, S - 12); g.fillText('N ↑', 12, 18); }
    for (const c of s.cars) { g.fillStyle = '#6fd3ff'; g.fillRect(X(c.pos.z) - 5, Yp(c.pos.x) - 5, 10, 10); }
    if (s.ferry) { g.fillStyle = '#fff'; g.beginPath(); g.arc(X(s.ferry.z), Yp(s.ferry.x), 6, 0, 7); g.fill(); }
    const ring = (cx, cy, radius, colour, dotted = false) => {
      if (!Number.isFinite(radius) || radius <= 0) return;
      g.save(); g.strokeStyle = colour; g.lineWidth = ui.big ? 3 : 5;
      if (dotted) g.setLineDash([10, 8]);
      g.beginPath(); g.arc(cx, cy, radius, 0, 2 * Math.PI); g.stroke(); g.restore();
    };
    if (s.zone) {
      const { x, z, r, shrinking, to } = s.zone;
      g.fillStyle = 'rgba(44,91,190,.23)';
      g.beginPath(); g.rect(0, 0, S, S); g.moveTo(X(z) + r * k, Yp(x)); g.arc(X(z), Yp(x), r * k, 0, 2 * Math.PI);
      g.fill('evenodd'); ring(X(z), Yp(x), r * k, '#77c9ff');
      if (shrinking && to) ring(X(to.z), Yp(to.x), to.r * k, '#effaff', true);
    }
    for (const mate of s.mates || []) {
      g.fillStyle = '#30d8ff'; g.strokeStyle = '#152d47'; g.lineWidth = 2;
      g.beginPath(); g.arc(X(mate.pos.z), Yp(mate.pos.x), ui.big ? 5 : 9, 0, 2 * Math.PI); g.fill(); g.stroke();
    }
    if (ui.big && s.zone) {
      g.fillStyle = 'rgba(13,24,44,.80)'; g.fillRect(8, 29, 183, 53);
      g.font = '14px "Microsoft YaHei",system-ui,sans-serif'; g.textAlign = 'left';
      g.fillStyle = '#77c9ff'; g.fillText('○  当前安全区', 16, 42);
      g.fillStyle = '#30d8ff'; g.fillText('●  GPU 队友', 16, 64);
      if (s.zone.shrinking && s.zone.to) { g.fillStyle = '#effaff'; g.fillText('◌  下一安全区', 95, 64); }
    }
    g.save(); g.translate(X(s.z), Yp(s.x)); g.rotate(-s.yaw); g.fillStyle = '#ffb000'; g.strokeStyle = '#111'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, -16); g.lineTo(10, 11); g.lineTo(0, 5); g.lineTo(-10, 11); g.closePath(); g.fill(); g.stroke(); g.restore();
  };
  return ui;
}
