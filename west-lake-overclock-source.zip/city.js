// The city east of the lake. The Hubin district is built from real building outlines (hubin_data.js); beyond it a street-grid
// infill stands in for the wider city. Also: Line 1 station entrances, zebra crossings, the music fountain, Qianjiang New Town.
import * as THREE from 'three';
import { signTexture } from './mats.js';
import { facadeMaterial } from './facade.js';
import { BUILDINGS } from './hubin_data.js';
import { LAND_Y as Y, BLOCKS, STATIONS, ROADS, WATER, CITY, MOUNDS, POI, pip, nearest } from './geo.js';

const REAL = { x0: -545, x1: 568, z0: -118, z1: 800 };                 // extent of the real-outline data
const inReal = (x, z, pad = 0) => x > REAL.x0 - pad && x < REAL.x1 + pad && z > REAL.z0 - pad && z < REAL.z1 + pad;
// the map has almost no heights, so: known buildings by name, then by use, then by footprint
const KNOWN = [['君悦', 66], ['解百新世纪', 60], ['新世纪', 60], ['工联CC二期', 44], ['工联CC', 38], ['龙翔服饰城', 30], ['明珠', 46], ['in77', 26], ['in88', 22], ['东坡大世界', 24], ['望湖宾馆', 40], ['友好饭店', 78],
  ['国贸', 70], ['银行', 44], ['大厦', 56], ['大酒店', 52], ['酒店', 38], ['宾馆', 32], ['饭店', 30], ['电信', 42], ['医院', 38], ['公寓', 44], ['国际', 60], ['中心', 46], ['广场', 40], ['书店', 24], ['剧院', 20]];
function heightOf([name, levels, height, type, pts], rnd) {
  if (height) return height; if (levels) return levels * 3.9;
  for (const [k, h] of KNOWN) if (name.includes(k)) return h;
  let a = 0; for (let i = 0; i < pts.length; i += 2) { const j = (i + 2) % pts.length; a += pts[i] * pts[j + 1] - pts[j] * pts[i + 1]; } a = Math.abs(a) / 2;
  if (type === 'apartments' || type === 'residential') return 20 + Math.floor(rnd(0, 5)) * 3.3;
  if (type === 'hospital' || type === 'hotel' || type === 'commercial') return a > 1500 ? 30 : 22;
  return (a < 120 ? 8 : a < 400 ? 13 : a < 1200 ? 18 : a < 3000 ? 23 : 27) + rnd(0, 3);
}

export function buildCity(ctx, fog) {
  const { scene, M, add, box, cyl, tick } = ctx, T = [];
  let r = 7; const rnd = (a = 0, b = 1) => a + ((r = (r * 16807) % 2147483647) / 2147483647) * (b - a);

  // ---- Hubin district: every mapped building extruded from its true outline
  const P = [], N = [], F = [], I = [], named = [];
  for (const b of BUILDINGS) {
    const [name, , , type, pts] = b; if (type === 'train_station' || name.includes('Apple')) continue;   // the station box is underground; Apple gets its glass pavilion below
    const style = /in77|in88|东坡|银泰/.test(name) ? 4 : /君悦|宾馆|酒店|饭店/.test(name) ? 5 : /工联|服饰城|解百|新世纪|明珠|百货/.test(name) ? 6 : 0;
    const H = heightOf(b, rnd), seed = style + rnd() * 0.98, n = pts.length / 2; let u = 0, longest = null;
    for (let i = 0; i < n; i++) {                                                                       // walls
      const ax = pts[i * 2], az = pts[i * 2 + 1], bx = pts[((i + 1) % n) * 2], bz = pts[((i + 1) % n) * 2 + 1], dx = bx - ax, dz = bz - az, L = Math.hypot(dx, dz); if (L < 0.05) continue;
      const nx = -dz / L, nz = dx / L, base = P.length / 3;
      P.push(ax, Y, az, bx, Y, bz, bx, Y + H, bz, ax, Y + H, az); for (let k = 0; k < 4; k++) N.push(nx, 0, nz);
      F.push(u, seed, H, 0, u + L, seed, H, 0, u + L, seed, H, 0, u, seed, H, 0); I.push(base, base + 1, base + 2, base, base + 2, base + 3); u += L;
      if (!longest || L > longest.L) longest = { L, x: (ax + bx) / 2, z: (az + bz) / 2, nx, nz };
    }
    const contour = []; for (let i = 0; i < n; i++) contour.push(new THREE.Vector2(pts[i * 2], pts[i * 2 + 1]));
    const base = P.length / 3; for (const c of contour) { P.push(c.x, Y + H, c.y); N.push(0, 1, 0); F.push(0, seed, H, 1); }
    for (const [a, c, d] of THREE.ShapeUtils.triangulateShape(contour, [])) I.push(base + a, base + c, base + d);                 // roof
    ctx.polys.push({ pts, h: H });
    if (name && longest.L > 9 && !/in77|工联|东坡|in88/.test(name)) named.push({ name, H, ...longest });
  }
  const rg = new THREE.BufferGeometry();
  rg.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); rg.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3)); rg.setAttribute('fa', new THREE.Float32BufferAttribute(F, 4)); rg.setIndex(I);
  const realMat = facadeMaterial(true); realMat.side = THREE.DoubleSide;
  const real = new THREE.Mesh(rg, realMat); real.castShadow = real.receiveShadow = true; ctx.solids.add(real);
  // name boards on the longest wall of each named building
  for (const s of named) { const t = signTexture([{ text: s.name, font: 'bold 76px "Microsoft YaHei","Segoe UI",sans-serif', color: '#f4e6c0' }], { w: 1024, h: 128, bg: '#1a1410' });
    const w = Math.min(s.L * 0.6, Math.max(6, s.name.length * 1.3)), m = add(new THREE.PlaneGeometry(w, w / 8), new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0.4, roughness: 0.5 }), s.x + s.nx * 0.25, Y + Math.min(s.H - 1.5, 6.2), s.z + s.nz * 0.25, { shadow: false });
    m.rotation.y = Math.atan2(s.nx, s.nz); }

  // ---- the big-brand signs and the Apple pavilion keep their hand-placed positions
  for (const [name, x0, x1, z0, z1, h, sign] of BLOCKS) {
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, mapped = inReal(cx, cz);
    if (name.startsWith('Apple')) { // built in detail by street.js
    } else if (!mapped) { T.push([cx, cz, x1 - x0, h, z1 - z0, 0, 1]); ctx.colliders.push(new THREE.Box3(new THREE.Vector3(x0, 0, z0), new THREE.Vector3(x1, h, z1))); }
    if (!sign || name === 'in77 B') continue;
    const big = sign.startsWith('in77'), tex = signTexture([{ text: sign, font: `bold ${big ? 150 : 110}px "Segoe UI","Microsoft YaHei",sans-serif` }, ...(big ? [{ text: '湖滨银泰', font: 'bold 70px "Microsoft YaHei",sans-serif', color: '#ffd9a0' }] : [])], { w: 1024, h: 384, bg: big ? '#b3122a' : '#14181d' });
    const sm = new THREE.MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.55, roughness: 0.5 }), sw = Math.min(22, (x1 - x0) * 0.5), sy = Y + Math.min(h - 4, 15);
    add(new THREE.PlaneGeometry(sw, sw * 0.375), sm, cx, sy, z0 - 0.6, { ry: Math.PI, shadow: false }); add(new THREE.PlaneGeometry(sw, sw * 0.375), sm, cx, sy, z1 + 0.6, { shadow: false });
  }

  // ---- infill beyond the mapped district: one building per grid cell wherever there is no road, water, hill or named block
  const roads = Object.values(ROADS).map(([pts, w]) => ({ pts, w })), mounds = Object.values(MOUNDS);
  for (let gx = -2600; gx < 2500; gx += 62) for (let gz = 40; gz < 4300; gz += 62) {
    const x = gx + rnd(8, 54), z = gz + rnd(8, 54), w = rnd(26, 44), d = rnd(24, 40), half = Math.max(w, d) / 2 + 3;
    if (inReal(x, z, half)) continue;
    if (x > -911 ? !pip(CITY, x, z) : z < 130) continue;
    if (pip(WATER, x, z) || mounds.some(([mx, mz, mr]) => Math.hypot(x - mx, z - mz) < mr + 30)) continue;
    if (BLOCKS.some(([, x0, x1, z0, z1]) => x > x0 - half - 8 && x < x1 + half + 8 && z > z0 - half - 8 && z < z1 + half + 8)) continue;
    if (roads.some((rd) => nearest(rd.pts, null, x, z).d < rd.w / 2 + half + 2)) continue;
    const wulin = x > 1200 && z < 1100, lake = z < 620 && !wulin;
    const h = lake ? rnd(14, 30) : wulin ? 50 + Math.pow(rnd(), 1.6) * 130 : rnd() < 0.07 ? rnd(95, 165) : 26 + Math.pow(rnd(), 1.8) * 60;
    T.push([x, z, w, h, d, 0, 0]); ctx.colliders.push(new THREE.Box3(new THREE.Vector3(x - w / 2, 0, z - d / 2), new THREE.Vector3(x + w / 2, h, z + d / 2)));
  }
  // Qianjiang New Town: about 5.3 km east and 1.3 km south of Hubin, on the Qiantang River
  const [qx, qz] = POI.qjnt;
  for (let i = 0; i < 80; i++) T.push([qx + rnd(-650, 650), qz + rnd(-500, 600), rnd(34, 52), 110 + Math.pow(rnd(), 1.7) * 200, rnd(34, 52), rnd(0, 0.7), 0]);
  for (const t of [...T]) if (t[3] > 95) T.push([t[0], t[1], t[2] * 0.72, t[3] * 0.16, t[4] * 0.72, t[5], 0, t[3]]);   // towers step back near the top

  const tg = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), towers = new THREE.InstancedMesh(tg, facadeMaterial(false), T.length);
  const o = new THREE.Object3D(), seeds = new Float32Array(T.length);
  T.forEach(([x, z, w, h, d, rot, , base = 0], i) => { o.position.set(x, Y + base, z); o.scale.set(w, h, d); o.rotation.y = rot; o.updateMatrix(); towers.setMatrixAt(i, o.matrix); seeds[i] = rnd(); });
  tg.setAttribute('seed', new THREE.InstancedBufferAttribute(seeds, 1)); towers.frustumCulled = false; towers.castShadow = towers.receiveShadow = true; ctx.solids.add(towers);

  // roofs for the infill: grey-tile pitched roofs on low blocks, plant rooms and water tanks on everything taller
  const lows = T.filter((t) => t[3] < 34 && !t[6] && t.length < 8), highs = T.filter((t) => t[3] >= 34 && t.length < 8);
  const rs = new THREE.Shape(); rs.moveTo(-0.5, 0); rs.lineTo(0.5, 0); rs.lineTo(0, 1); rs.closePath();
  const roofM = M.tile.clone(); for (const k of ['map', 'normalMap', 'roughnessMap']) { roofM[k] = roofM[k].clone(); roofM[k].repeat.set(4, 3); } roofM.metalnessMap = roofM.roughnessMap;
  const roofs = new THREE.InstancedMesh(new THREE.ExtrudeGeometry(rs, { depth: 1, bevelEnabled: false }).translate(0, 0, -0.5), roofM, lows.length);
  lows.forEach(([x, z, w, h, d], i) => { o.position.set(x, Y + h, z); o.rotation.y = w > d ? Math.PI / 2 : 0; o.scale.set(Math.min(w, d) + 1.6, Math.min(w, d) * 0.3, Math.max(w, d) + 1.6); o.updateMatrix(); roofs.setMatrixAt(i, o.matrix); });
  const plant = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), M.concrete, highs.length * 2);
  highs.forEach(([x, z, w, h, d, rot], i) => { o.rotation.y = rot;
    o.position.set(x + w * 0.14, Y + h, z - d * 0.1); o.scale.set(w * 0.34, 3, d * 0.3); o.updateMatrix(); plant.setMatrixAt(i * 2, o.matrix);
    o.position.set(x - w * 0.24, Y + h, z + d * 0.22); o.scale.set(w * 0.14, 1.8, d * 0.16); o.updateMatrix(); plant.setMatrixAt(i * 2 + 1, o.matrix); });
  for (const m of [roofs, plant]) { m.castShadow = m.receiveShadow = true; m.frustumCulled = false; scene.add(m); }

  // Qianjiang landmarks: the golden sphere hotel, the crescent grand theatre, a pair of twisted towers
  const far = (g, m, x, y, z) => { const b = new THREE.Mesh(g, m); b.position.set(x, y, z); scene.add(b); return b; };
  far(new THREE.SphereGeometry(46, 48, 32), new THREE.MeshStandardMaterial({ color: 0xd9a63a, metalness: 1, roughness: 0.22 }), qx + 200, 44, qz - 420);
  far(new THREE.SphereGeometry(60, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xcfd6dc, metalness: 0.7, roughness: 0.25 }), qx + 60, 0, qz - 460).scale.set(1, 0.42, 0.55);
  const twist = (x, z, s) => { const g = new THREE.CylinderGeometry(26, 32, 250, 4, 40), p = g.attributes.position;
    for (let i = 0; i < p.count; i++) { const a = (p.getY(i) / 250 + 0.5) * 0.9 * s, px = p.getX(i), pz = p.getZ(i); p.setXYZ(i, px * Math.cos(a) - pz * Math.sin(a), p.getY(i), px * Math.sin(a) + pz * Math.cos(a)); }
    g.computeVertexNormals(); far(g, new THREE.MeshStandardMaterial({ color: 0x9fb4c8, metalness: 0.9, roughness: 0.18 }), x, 125, z); };
  twist(qx + 520, qz + 260, 1); twist(qx + 470, qz + 320, -1);

  // ---- zebra crossings where the side streets meet Yan'an Road
  const zebra = [], zx = (x, z0, z1) => { for (let z = z0; z <= z1; z += 1.1) zebra.push([x, z, 4, 0.5]); }, zz = (z, x0, x1) => { for (let x = x0; x <= x1; x += 1.1) zebra.push([x, z, 0.5, 4]); };
  for (const [jx, jz, cw] of [[2, 348, 14], [165, 342, 10], [-143, 353, 10], [-262, 358, 10], [-398, 363, 20], [468, 331, 24]]) { zx(jx - cw / 2 - 4, jz - 11, jz + 11); zx(jx + cw / 2 + 4, jz - 11, jz + 11); zz(jz - 16, jx - cw / 2 + 1, jx + cw / 2 - 1); zz(jz + 16, jx - cw / 2 + 1, jx + cw / 2 - 1); }
  const zI = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 0.02, 1), ctx.over(new THREE.MeshStandardMaterial({ color: 0xe8e6da, roughness: 0.6 }), 8), zebra.length);
  zebra.forEach(([x, z, sx, sz], i) => { o.position.set(x, Y + 0.1, z); o.rotation.set(0, 0, 0); o.scale.set(sx, 1, sz); o.updateMatrix(); zI.setMatrixAt(i, o.matrix); }); zI.receiveShadow = true; zI.frustumCulled = false; scene.add(zI);

  // ---- the West Lake music fountain: a line of jets in the water off the Hubin promenade
  const jets = 36, jI = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.1, 0.16, 1, 8).translate(0, 0.5, 0), new THREE.MeshStandardMaterial({ color: 0xf2f8ff, emissive: 0x9fc4e0, emissiveIntensity: 0.5, transparent: true, opacity: 0.7, roughness: 0.2, depthWrite: false }), jets);
  jI.frustumCulled = false; scene.add(jI); ctx.noAO.push(jI);
  tick.push((t) => { for (let i = 0; i < jets; i++) { const s = (i - jets / 2) * 2.6; o.position.set(-12 - 0.855 * s - 12, 0, 22 + 0.52 * s - 20); o.rotation.set(0, 0, 0);
    o.scale.set(1, 2 + 9 * Math.pow(Math.abs(Math.sin(t * 0.9 + i * 0.32) * Math.cos(t * 0.37 + i * 0.11)), 1.5), 1); o.updateMatrix(); jI.setMatrixAt(i, o.matrix); } jI.instanceMatrix.needsUpdate = true; });

  // ---- Metro Line 1 entrances: the four Longxiangqiao exits on Yan'an Road, plus one each at Fengqi Road and Ding'an Road
  const red = new THREE.MeshStandardMaterial({ color: 0xd8232a, roughness: 0.5 }), dark = new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 1 }), metro = [];
  const entrance = (si, label, x, z, face) => { // face: +1 opens east, -1 opens west
    const st = STATIONS[si];
    box(3.6, 0.1, 6.4, dark, x, Y + 0.06, z, { shadow: false });                                    // stairwell
    for (let k = 0; k < 6; k++) box(3.2, 0.18, 0.5, M.concrete, x, Y - 0.1 - k * 0.2, z + face * (2.4 - k * 0.9), { s: 1 });
    for (const sx of [-1.9, 1.9]) { box(0.12, 1.1, 6.4, M.glass, x + sx, Y + 0.55, z, { collide: true }); for (const sz of [-3, 3]) cyl(0.07, 0.07, 3, M.galv, x + sx, Y + 1.5, z + sz, {}, 8); }
    box(3.9, 1.1, 0.12, M.glass, x, Y + 0.55, z - face * 3.2, { collide: true });
    box(4.4, 0.14, 7.2, M.glass, x, Y + 3.05, z, { s: 1 }); box(4.4, 0.3, 0.2, red, x, Y + 2.8, z + face * 3.5, { s: 1 });
    const t = signTexture([{ text: `地铁 ${st.name}`, font: 'bold 96px "Microsoft YaHei",sans-serif' }, { text: `${st.en} · Line 1${label ? ' · Exit ' + label : ''}`, font: '600 54px "Segoe UI",sans-serif', color: '#ffd6d6' }], { w: 1024, h: 256, bg: '#d8232a' });
    const sm = new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0.5 });
    add(new THREE.PlaneGeometry(4, 1), sm, x, Y + 3.7, z + face * 3.55, { ry: face > 0 ? 0 : Math.PI, shadow: false }); add(new THREE.PlaneGeometry(4, 1), sm, x, Y + 3.7, z + face * 3.45, { ry: face > 0 ? Math.PI : 0, shadow: false });
    metro.push({ si, x, z: z + face * 4.4 });
  };
  entrance(1, 'A', 148, 374, 1); entrance(1, 'B', 148, 335, 1); entrance(1, 'C', 2, 334, -1); entrance(1, 'D', 2, 374, 1);
  entrance(0, '', 1006, 297, -1); entrance(2, '', -900, 750, 1);
  return { metro };
}
