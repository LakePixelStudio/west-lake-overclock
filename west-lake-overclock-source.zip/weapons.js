// The arsenal: three graphics cards, modelled part by part, held like firearms. Fans spin with temperature.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const CARDS = [
  { name: 'GT-LP 2GB', sub: 'low-profile · semi', L: 0.17, W: 0.075, T: 0.036, fans: 1, hex: 0xffc070, dmg: 30, rate: 0.17, heat: 6, vram: 0, auto: false, spread: 0.004, kick: 0.8 },
  { name: 'RX TRI 12GB', sub: 'triple fan · full auto', L: 0.32, W: 0.13, T: 0.055, fans: 3, hex: 0x30d8ff, dmg: 17, rate: 0.075, heat: 3.0, vram: 0.05, auto: true, spread: 0.011, kick: 0.45 },
  { name: 'TITAN RT 24GB', sub: 'ray tracer · piercing beam', L: 0.36, W: 0.15, T: 0.082, fans: 3, hex: 0xb44cff, dmg: 160, rate: 0.95, heat: 36, vram: 1.5, auto: false, spread: 0, kick: 2.4, ray: true },
];

function fanGeo(r) {
  const parts = [new THREE.CylinderGeometry(r * 0.3, r * 0.3, 0.006, 20)];
  for (let k = 0; k < 9; k++) parts.push(new THREE.BoxGeometry(r * 0.72, 0.0015, r * 0.36).rotateX(0.5).rotateY(-0.25).translate(r * 0.62, 0, 0).rotateY(k * Math.PI * 2 / 9));
  return mergeGeometries(parts.map((g) => g.toNonIndexed()));
}

function makeCard(M, d) {
  const g = new THREE.Group(), fans = [], { L, W, T } = d;
  const rgb = new THREE.MeshStandardMaterial({ color: 0, emissive: d.hex, emissiveIntensity: 3 });
  const core = new THREE.MeshStandardMaterial({ color: 0, emissive: d.hex, emissiveIntensity: 0 });
  const p = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.receiveShadow = true; g.add(o); return o; };
  const rb = (w, h, dd, r) => new RoundedBoxGeometry(w, h, dd, 3, r);
  // card lies flat: backplate at y=0, fans on top (+y), length along z, front (emitter) at -z
  p(rb(W, 0.004, L, 0.0015), M.steel, 0, 0, 0);                                   // brushed backplate
  p(new THREE.BoxGeometry(W - 0.008, 0.003, L - 0.012), M.pcb, 0, 0.005, 0);      // PCB
  p(new THREE.BoxGeometry(0.01, 0.0025, 0.085), M.gold, -W / 2 - 0.004, 0.005, L * 0.12); // PCIe edge fingers
  const hs = T - 0.026;
  const fin = p(new THREE.BoxGeometry(W - 0.014, hs, L - 0.02), M.fins, 0, 0.007 + hs / 2, 0); fin.material = M.fins;
  for (let i = 0; i < (d.ray ? 6 : d.fans > 1 ? 4 : 2); i++) {                    // copper heat pipes poking out of the front
    const x = (i - (d.ray ? 2.5 : d.fans > 1 ? 1.5 : 0.5)) * 0.016;
    const pipe = p(new THREE.CylinderGeometry(0.004, 0.004, L * 0.5, 10), M.copper, x, 0.012 + hs * 0.5, -L * 0.28); pipe.rotation.x = Math.PI / 2;
    const tip = p(new THREE.SphereGeometry(0.0045, 10, 8), core, x, 0.012 + hs * 0.5, -L * 0.53);
    tip.userData.tip = true;
  }
  const sy = T - 0.012;
  p(rb(W, 0.016, L, 0.006), M.shroud, 0, sy, 0);                                   // shroud
  for (const s of [-1, 1]) p(rb(0.006, T - 0.012, L * 0.96, 0.002), M.shroud, s * (W / 2 - 0.003), (T - 0.012) / 2 + 0.004, 0);
  p(new THREE.BoxGeometry(0.003, 0.006, L * 0.82), rgb, W / 2 + 0.0005, sy - 0.002, 0);    // RGB light bar on the top edge
  p(new THREE.BoxGeometry(W * 0.5, 0.0015, 0.004), rgb, 0, sy + 0.0085, -L / 2 + 0.012);
  const r = Math.min(W * 0.42, (L / d.fans) * 0.44), fg = fanGeo(r);
  for (let i = 0; i < d.fans; i++) {
    const z = (i - (d.fans - 1) / 2) * (L / d.fans) * 0.98;
    p(new THREE.CylinderGeometry(r * 1.06, r * 1.06, 0.002, 40), M.rubber, 0, sy + 0.0085, z);  // fan well
    p(new THREE.TorusGeometry(r * 1.07, 0.0022, 8, 48), i === 1 || d.fans === 1 ? rgb : M.steel, 0, sy + 0.0095, z).rotation.x = Math.PI / 2;
    const f = p(fg, M.rubber, 0, sy + 0.0125, z); fans.push(f);
    p(new THREE.CylinderGeometry(r * 0.2, r * 0.2, 0.0005, 20), M.galv, 0, sy + 0.0162, z);     // hub sticker
  }
  p(new THREE.BoxGeometry(W + 0.012, T + 0.004, 0.0015), new THREE.MeshStandardMaterial({ color: 0x2c2e31, metalness: 1, roughness: 0.45 }), 0, T / 2 - 0.004, L / 2 + 0.001);   // PCI bracket
  for (let i = 0; i < 3; i++) p(new THREE.BoxGeometry(0.017, 0.006, 0.002), M.rubber, -W * 0.28 + i * W * 0.28, 0.014, L / 2 + 0.002); // display ports
  p(rb(0.03, 0.012, 0.014, 0.002), M.rubber, W * 0.25, sy + 0.012, L * 0.18);                    // power connector
  const cab = new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(W * 0.25, sy + 0.016, L * 0.18), new THREE.Vector3(W * 0.4, sy + 0.05, L * 0.3), new THREE.Vector3(W * 0.2, 0.02, L * 0.62), new THREE.Vector3(0, -0.12, L * 0.7)]), 20, 0.0045, 6);
  p(cab, M.rubber, 0, 0, 0);                                                                     // power cable trailing back to you
  // pistol grip bolted under the bracket end, so it reads as a weapon
  const grip = p(rb(0.03, 0.1, 0.036, 0.008), M.shroud, 0, -0.05, L / 2 - 0.045); grip.rotation.x = -0.25;
  p(rb(0.012, 0.012, 0.05, 0.003), M.steel, 0, -0.012, L / 2 - 0.085);
  const muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.012 + hs * 0.5, -L * 0.56); g.add(muzzle);
  return { g, fans, rgb, core, muzzle, def: d, temp: 38, throttled: false, cool: 0 };
}

export function createWeapons(camera, M) {
  const root = new THREE.Group(); camera.add(root);
  const cards = CARDS.map((d) => { const c = makeCard(M, d); c.g.visible = false; root.add(c.g); return c; });
  // muzzle flash sprite (drawn on a canvas) + light
  const cv = document.createElement('canvas'); cv.width = cv.height = 128; const x = cv.getContext('2d'); x.translate(64, 64);
  for (let i = 0; i < 10; i++) { x.rotate(0.4 + Math.random()); const l = 28 + Math.random() * 34, gr = x.createLinearGradient(0, 0, l, 0); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.beginPath(); x.moveTo(0, -6); x.lineTo(l, 0); x.lineTo(0, 6); x.fill(); }
  const rg = x.createRadialGradient(0, 0, 0, 0, 0, 30); rg.addColorStop(0, 'rgba(255,255,255,1)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = rg; x.fillRect(-64, -64, 128, 128);
  const flash = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.26), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
  flash.visible = false; camera.add(flash);
  const light = new THREE.PointLight(0xffffff, 0, 14, 2); light.position.set(0, 0, -0.9); camera.add(light);

  const HIP = new THREE.Vector3(0.15, -0.175, -0.38), ADS = new THREE.Vector3(0.02, -0.105, -0.3);
  const W = { cards, cur: 1, next: 1, swap: 0, recoil: 0, flashT: 0, adsT: 0, sway: new THREE.Vector2(), flash, light, root,
    get card() { return cards[W.cur]; },
    select(i) { if (i !== W.next && cards[i]) { W.next = i; W.swap = 0.36; } },
    kick() { const c = W.card; W.recoil = Math.min(W.recoil + c.def.kick, 3); W.flashT = c.def.ray ? 0.12 : 0.04; flash.material.color.set(c.def.hex).multiplyScalar(c.def.ray ? 9 : 5); light.color.set(c.def.hex); flash.rotation.z = Math.random() * 6.3; flash.scale.setScalar((0.7 + Math.random() * 0.5) * (c.def.ray ? 2 : 1)); },
    update(dt, s) { // s: {ads, bobX, bobY, mdx, mdy, t, vy}
      const k = (a, b, r) => a + (b - a) * (1 - Math.exp(-r * dt));
      if (W.swap > 0) { W.swap -= dt; if (W.swap < 0.18 && W.cur !== W.next) W.cur = W.next; }
      const drop = W.swap > 0 ? Math.sin(Math.min(1, W.swap / 0.36) * Math.PI) : 0;
      cards.forEach((c, i) => {
        c.g.visible = i === W.cur;
        const heat = Math.min(1, Math.max(0, (c.temp - 38) / 57));
        for (const f of c.fans) f.rotation.y -= (8 + heat * 70) * dt;                   // fan curve
        c.rgb.emissive.set(c.def.hex).lerp(new THREE.Color(0xff2a08), heat * heat);      // light bar shifts red as it cooks
        c.rgb.emissiveIntensity = c.throttled ? 2 + 4 * Math.abs(Math.sin(s.t * 9)) : 3 + heat * 3;
        c.core.emissiveIntensity = k(c.core.emissiveIntensity, 0.4 + heat * 2, 6);
      });
      const c = W.card; W.adsT = k(W.adsT, s.ads ? 1 : 0, 16); W.recoil = k(W.recoil, 0, 10);
      W.sway.x = k(W.sway.x, -s.mdx * 0.0006, 10); W.sway.y = k(W.sway.y, s.mdy * 0.0006, 10);
      const hip = 1 - W.adsT, g = c.g;
      g.position.lerpVectors(HIP, ADS, W.adsT);
      g.position.x += (W.sway.x + s.bobX * 0.5) * hip; g.position.y += (W.sway.y - s.bobY * 0.4) * hip - drop * 0.3 - Math.max(0, -s.vy) * 0.004 + (0.33 - c.def.L) * 0.1;
      g.position.z += W.recoil * 0.022 + c.def.L * 0.5 - 0.16;
      g.rotation.set(W.recoil * 0.03 * (0.4 + hip) + W.sway.y * 1.5 - drop * 0.8, 0.07 * hip + W.sway.x * 2 * hip, 0.72 + 0.5 * W.adsT - W.sway.x * 1.2 * hip);
      W.flashT -= dt; flash.visible = W.flashT > 0; light.intensity = W.flashT > 0 ? (c.def.ray ? 160 : 50) : 0;
      if (flash.visible) { c.muzzle.getWorldPosition(flash.position); camera.worldToLocal(flash.position); if (W.flashT > 0.02) c.core.emissiveIntensity = 30; }
    },
  };
  return W;
}
