// Public transport: Metro Line 1 (ride a modelled carriage between Fengqi Road, Longxiangqiao and Ding'an Road) and the lake ferry
// between the Hubin pier and the Leifeng Pagoda pier.
import * as THREE from 'three';
import { LAND_Y as Y, STATIONS, BOAT_ROUTE, PIER_HUBIN, PIER_LEIFENG, makeStrip, pointAt, groundY } from './geo.js';

export function createTransit(ctx, camera, metro, note) {
  const { scene, M } = ctx;
  // ---------------- train interior, parked far below ground
  const tr = new THREE.Group(); tr.position.set(0, -80, 0); scene.add(tr);
  const mat = (color, roughness = 0.6, metalness = 0) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
  const mk = (w, h, d, m, x, y, z) => { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); tr.add(o); return o; };
  const wallM = mat(0xe4e6e8, 0.5), red = mat(0xd8232a, 0.5), seatM = mat(0x1f4fa0, 0.55), winM = mat(0x020304, 0.05, 0.8), steel = mat(0xb9bcc0, 0.25, 1);
  mk(2.9, 0.1, 20, mat(0x3a3d42, 0.7), 0, 0, 0); mk(2.9, 0.1, 20, wallM, 0, 2.35, 0); mk(1.6, 0.03, 18, M.emit(0xf2f6ff, 3), 0, 2.29, 0);
  for (const z of [-10, 10]) mk(2.9, 2.4, 0.1, wallM, 0, 1.2, z);
  const streaks = [];
  for (const s of [-1, 1]) {
    mk(0.1, 2.4, 20, wallM, s * 1.45, 1.2, 0); mk(0.02, 0.07, 20, red, s * 1.39, 2.05, 0);
    for (let i = 0; i < 4; i++) { const z = -7.5 + i * 5;
      mk(0.02, 0.95, 2.6, winM, s * 1.39, 1.5, z); mk(0.46, 0.08, 2.6, seatM, s * 1.15, 0.45, z); mk(0.08, 0.5, 2.6, seatM, s * 1.36, 0.75, z);
      mk(0.03, 1.95, 1.1, mat(0xc9ccd0, 0.3, 0.6), s * 1.39, 1.0, z + 2.5);                                                             // sliding door leaf
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 2.25, 10), steel); p.position.set(s * 0.6, 1.17, z + 1.7); tr.add(p); }
    const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 19, 8).rotateX(Math.PI / 2), steel); rail.position.set(s * 0.6, 1.95, 0); tr.add(rail);
    for (let i = 0; i < 7; i++) { const b = mk(0.015, 0.05, 1.4, M.emit(0xffd9a0, 6), s * 1.375, 1.25 + (i % 3) * 0.22, 0); b.userData.o = i * 2.9; streaks.push(b); }   // tunnel lights sliding past the glass
  }
  const sc = document.createElement('canvas'); sc.width = 1024; sc.height = 160; const sg = sc.getContext('2d'), st = new THREE.CanvasTexture(sc); st.colorSpace = THREE.SRGBColorSpace;
  const setSign = (text) => { sg.fillStyle = '#050505'; sg.fillRect(0, 0, 1024, 160); sg.fillStyle = '#ff7a2a'; sg.font = 'bold 76px "Microsoft YaHei","Segoe UI",sans-serif'; sg.textAlign = 'center'; sg.textBaseline = 'middle'; sg.fillText(text, 512, 84); st.needsUpdate = true; };
  for (const z of [-9.93, 9.93]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.31), new THREE.MeshStandardMaterial({ emissiveMap: st, emissive: 0xffffff, emissiveIntensity: 2, color: 0 })); p.position.set(0, 2.05, z); p.rotation.y = z > 0 ? Math.PI : 0; tr.add(p); }
  for (const z of [-5, 5]) { const l = new THREE.PointLight(0xf2f6ff, 9, 14, 2); l.position.set(0, 2.1, z); tr.add(l); }

  // ---------------- lake ferry
  const route = makeStrip(BOAT_ROUTE, 0), ferry = ctx.makeBoat(1.7); ctx.solids.add(ferry);
  const boat = { s: 0, v: 0, dir: 1 }, ends = [PIER_HUBIN, PIER_LEIFENG];
  const placeFerry = (t) => { const [x, z, dx, dz] = pointAt(route, boat.s); ferry.position.set(x, 0.12 + Math.sin(t * 0.9) * 0.05, z); ferry.rotation.set(0, Math.atan2(dx, dz), Math.sin(t * 0.7) * 0.02); };
  placeFerry(0);
  const pierEnd = (i) => pointAt(ends[i], ends[i].len - 1.5);

  let ride = null, tNow = 0;
  const stationAt = (p) => metro.find((m) => Math.hypot(p.x - m.x, p.z - m.z) < 3.2);
  const pierAt = (p) => [0, 1].find((i) => { const [x, z] = pierEnd(i); return Math.hypot(p.x - x, p.z - z) < 5; });
  return {
    get riding() { return !!ride; }, get safe() { return ride?.kind === 'metro'; },
    prompt(p) { // text for the HUD when something can be boarded here
      const m = stationAt(p); if (m) return `E — 地铁1号线 Metro Line 1 · ${STATIONS[m.si].name}`;
      const i = pierAt(p); if (i !== undefined) return i === 0 ? 'E — ferry to Leifeng Pagoda 雷峰塔' : 'E — ferry back to Hubin 湖滨';
      return '';
    },
    key(player) { // E pressed; returns true when handled
      if (ride?.kind === 'metro') {
        if (ride.phase !== 'stop') { note('Doors open at the next station'); return true; }
        const e = metro.find((m) => m.si === ride.idx); player.pos.set(e.x, groundY(e.x, e.z), e.z); player.vel.set(0, 0, 0);
        note(`${STATIONS[ride.idx].name} · ${STATIONS[ride.idx].en}`); ride = null; return true;
      }
      if (ride) { note('Stay aboard — the ferry is under way'); return true; }
      const m = stationAt(player.pos);
      if (m) { ride = { kind: 'metro', idx: m.si, dir: m.si === STATIONS.length - 1 ? -1 : 1, phase: 'run', t: 0 }; setSign(`下一站 Next: ${STATIONS[m.si + ride.dir].name}`); note('Metro Line 1 — mouse to look around'); return true; }
      const i = pierAt(player.pos);
      if (i !== undefined) { boat.s = i ? route.len : 0; boat.dir = i ? -1 : 1; boat.v = 0; ride = { kind: 'boat', to: 1 - i }; note(i ? 'Ferry to Hubin 湖滨' : 'Ferry to Leifeng Pagoda 雷峰塔 — about two minutes'); return true; }
      return false;
    },
    update(dt, player) { // while riding this owns the camera; returns false when not riding
      tNow += dt;
      if (!ride) { placeFerry(tNow); return false; }
      if (ride.kind === 'metro') {
        ride.t += dt; let sp = 0;
        if (ride.phase === 'run') {
          sp = Math.sin(Math.PI * Math.min(1, ride.t / 10));
          if (ride.t >= 10) { ride.idx += ride.dir; ride.phase = 'stop'; ride.t = 0; const s = STATIONS[ride.idx]; setSign(`${s.name}  ${s.en}`); note(`到站 ${s.name} · ${s.en} — press E to get off`); if (ride.idx === 0 || ride.idx === STATIONS.length - 1) ride.dir *= -1; }
        } else if (ride.t > 6) { ride.phase = 'run'; ride.t = 0; setSign(`下一站 Next: ${STATIONS[ride.idx + ride.dir].name}`); }
        for (const b of streaks) { b.userData.o = (b.userData.o + sp * 70 * dt) % 20; b.position.z = b.userData.o - 10; b.visible = sp > 0.02; }
        camera.position.set(0.35 + Math.sin(tNow * 13) * 0.004 * sp, -80 + 1.32 + Math.sin(tNow * 17) * 0.006 * sp, 1.2); camera.rotation.set(player.pitch, player.yaw, 0);
      } else {
        const left = boat.dir > 0 ? route.len - boat.s : boat.s, target = Math.min(27, Math.max(3, left * 0.22));
        boat.v += Math.sign(target - boat.v) * Math.min(Math.abs(target - boat.v), 5 * dt); boat.s += boat.dir * boat.v * dt; placeFerry(tNow);
        player.pos.set(ferry.position.x, Y, ferry.position.z); player.vel.set(0, 0, 0);
        camera.position.set(ferry.position.x, ferry.position.y + 2.5, ferry.position.z); camera.rotation.set(player.pitch, player.yaw, ferry.rotation.z);
        if (left < 1.5) { const [x, z] = pierEnd(ride.to); player.pos.set(x, Y, z); boat.s = boat.dir > 0 ? route.len : 0; note(ride.to ? '雷峰塔码头 Leifeng Pagoda pier — the path leads up to the pagoda' : '湖滨码头 Hubin pier'); ride = null; }
      }
      camera.fov += (70 - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix(); camera.updateMatrixWorld();
      return true;
    },
    boat, ferry, route,
  };
}
