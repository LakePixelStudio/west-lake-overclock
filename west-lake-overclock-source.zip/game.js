import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { makeMats } from './mats.js';
import { buildEnv, SUN, FOG, FOG_COLOR } from './env.js';
import { buildWorld } from './world.js';
import { buildScenery } from './scenery.js';
import { buildCity } from './city.js';
import { buildPower, makeRam } from './power.js';
import { createWeapons } from './weapons.js';
import { createCars } from './vehicle.js';
import { createTransit } from './transit.js';
import { createUI } from './ui.js';
import { initAudio, sfx, hum } from './audio.js';
import { LAND_Y, groundY, walkable, POI, discInPoly, pipFlat } from './geo.js';

const $ = (id) => document.getElementById(id);
const rand = (a, b) => a + Math.random() * (b - a);
const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));

const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.46; // applied by OutputPass
document.body.prepend(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.08, 16000);
camera.rotation.order = 'YXZ'; scene.add(camera);
const fx = new THREE.Group(); scene.add(fx); // additive / transparent effects, hidden from the AO pass

let M, env, world, zones, W, cars, transit, ui, driving = null, composer, film, started = false;
const SPAWN = [-18, 96], POWER = [-1900, -3133]; // Hubin promenade by the music fountain; energy site west of Yanggongdi

// ---------------------------------------------------------------- player + collision
const player = { pos: new THREE.Vector3(SPAWN[0], LAND_Y, SPAWN[1]), vel: new THREE.Vector3(), yaw: -0.3, pitch: 0.03, hp: 100, onGround: true, lastHurt: -99, bob: 0, vram: 16 };
const R = 0.38, EYE = 1.68, VRAM_MAX = 24;
function blocked(x, y, z) {
  if (!walkable(x, z)) return true;
  const n = world.near(x, z);
  for (const b of n.boxes) if (x > b.min.x - R && x < b.max.x + R && z > b.min.z - R && z < b.max.z + R && b.max.y > y + 0.35 && b.min.y < y + 1.75) return true;
  for (const c of n.circles) if (Math.hypot(x - c.x, z - c.z) < c.r + R) return true;
  for (const p of n.polys) if (y < p.h && discInPoly(p.pts, x, z, R)) return true;
  for (const c of world.dyn) if (Math.hypot(x - c.x, z - c.z) < c.r + R) return true;
  return false;
}
function groundAt(x, y, z) {
  let g = groundY(x, z);
  for (const b of world.near(x, z).boxes) if (x > b.min.x - R * 0.5 && x < b.max.x + R * 0.5 && z > b.min.z - R * 0.5 && z < b.max.z + R * 0.5 && b.max.y <= y + 0.35) g = Math.max(g, b.max.y);
  return g;
}
const keys = {}; let locked = false, touchPlay = false, firing = false, trig = false, ads = false, mdx = 0, mdy = 0;
const playing = () => locked || touchPlay;
const look = (dx, dy) => { const s = 0.0021 * (ads ? 0.55 : 1); player.yaw -= dx * s; player.pitch = Math.max(-1.5, Math.min(1.5, player.pitch - dy * s)); mdx += dx; mdy += dy; };
addEventListener('keydown', (e) => { keys[e.code] = true; if (!playing() || e.repeat) return; if (/^Digit[123]$/.test(e.code)) W.select(+e.code[5] - 1); if (e.code === 'KeyE') use(); if (e.code === 'KeyF' && driving) toggleAuto(); });
addEventListener('keyup', (e) => { keys[e.code] = false; });
addEventListener('wheel', (e) => { if (locked) W.select((W.next + (e.deltaY > 0 ? 1 : 2)) % 3); });
addEventListener('mousemove', (e) => { if (locked) look(e.movementX, e.movementY); });
addEventListener('mousedown', (e) => { if (!locked) return; if (e.button === 0) firing = trig = true; if (e.button === 2) ads = true; });
addEventListener('mouseup', (e) => { if (e.button === 0) firing = false; if (e.button === 2) ads = false; });
addEventListener('contextmenu', (e) => e.preventDefault());
const overlay = $('overlay');
const start = () => { if (!started) return; initAudio(); if (player.hp <= 0) resetGame();
  if (ui.touch) { touchPlay = true; overlay.style.display = 'none'; document.documentElement.requestFullscreen?.().catch(() => {}); } else renderer.domElement.requestPointerLock(); };
overlay.addEventListener('click', start);
overlay.addEventListener('keydown', (e) => { if (e.code === 'Enter' || e.code === 'Space') start(); });
document.addEventListener('pointerlockchange', () => {
  locked = document.pointerLockElement === renderer.domElement; if (ui.touch) return; overlay.style.display = locked ? 'none' : 'flex';
  if (!locked) { firing = ads = false; if (player.hp > 0) $('msg').textContent = 'Paused — click to resume'; }
});
let noteT = 0; const note = (s) => { $('note').textContent = s; $('note').style.opacity = 1; noteT = 3; };

// E: ride controls first, then cars, then stations and piers
function use() {
  if (transit.riding) return transit.key(player);
  if (driving) { const c = driving, h = c.heading;
    if (Math.abs(c.v) > 3) return note('Slow down before getting out');
    for (const s of [1, -1, 2.2, -2.2]) { const x = c.pos.x - Math.cos(h) * 1.9 * s, z = c.pos.z + Math.sin(h) * 1.9 * s;
      if (!blocked(x, c.pos.y, z)) { player.pos.set(x, groundY(x, z), z); player.vel.set(0, 0, 0); player.yaw = h; player.pitch = 0; c.auto = false; driving = null; return; } }
    return note('No room to get out here'); }
  const c = cars.nearest(player.pos, 3.6);
  if (c) { driving = c; c.auto = ui.touch; note(ui.touch ? 'Auto-drive on — steer or brake any time to take over' : 'Driving — WASD, Space drift, F auto-drive, E get out'); return; }
  transit.key(player);
}
const toggleAuto = () => { driving.auto = !driving.auto; note(driving.auto ? 'Auto-drive ON — follows the lake ring road; your inputs still override' : 'Auto-drive off'); };

// ---------------------------------------------------------------- pooled effects
const SP = 1600, spPos = new Float32Array(SP * 3).fill(-99), spCol = new Float32Array(SP * 3), spVel = new Float32Array(SP * 3), spLife = new Float32Array(SP);
let spI = 0, sparks, decals = [], decalI = 0, tracers = [], tracerI = 0, beam, boomLight, lampLights = [];
function buildFx() {
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(spPos, 3)); g.setAttribute('color', new THREE.BufferAttribute(spCol, 3));
  sparks = new THREE.Points(g, new THREE.PointsMaterial({ size: 0.06, vertexColors: true, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })); sparks.frustumCulled = false; fx.add(sparks);
  const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), rg = x.createRadialGradient(32, 32, 2, 32, 32, 30);
  rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(0.3, 'rgba(10,8,8,.9)'); rg.addColorStop(0.55, 'rgba(30,26,24,.45)'); rg.addColorStop(1, 'rgba(40,38,36,0)'); x.fillStyle = rg; x.fillRect(0, 0, 64, 64);
  const dm = new THREE.MeshStandardMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, roughness: 1, polygonOffset: true, polygonOffsetFactor: -8, polygonOffsetUnits: -8 });
  for (let i = 0; i < 90; i++) { const d = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.16), dm); d.visible = false; fx.add(d); decals.push(d); }
  const tg = new THREE.CylinderGeometry(1, 1, 1, 8).rotateX(Math.PI / 2), tm = () => new THREE.MeshBasicMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
  for (let i = 0; i < 10; i++) { const t = new THREE.Mesh(tg, tm()); t.visible = false; t.userData.life = 0; fx.add(t); tracers.push(t); }
  beam = new THREE.Mesh(tg, tm()); beam.visible = false; beam.userData.life = 0; fx.add(beam);
  boomLight = new THREE.PointLight(0xff7a30, 0, 30, 2); scene.add(boomLight);
  for (let i = 0; i < 4; i++) { const l = new THREE.PointLight(0xffb870, 10, 20, 2); scene.add(l); lampLights.push(l); } // roam to the nearest lamp posts
}
function burst(p, n, count, speed, r, g, b) {
  for (let i = 0; i < count; i++) {
    const j = (spI = (spI + 1) % SP) * 3;
    spPos[j] = p.x; spPos[j + 1] = p.y; spPos[j + 2] = p.z;
    spVel[j] = (n.x * 0.8 + rand(-1, 1)) * speed * Math.random(); spVel[j + 1] = (n.y * 0.8 + rand(-0.6, 1.2)) * speed * Math.random(); spVel[j + 2] = (n.z * 0.8 + rand(-1, 1)) * speed * Math.random();
    spCol[j] = r; spCol[j + 1] = g; spCol[j + 2] = b; spLife[spI] = rand(0.25, 0.9);
  }
}
function streak(mesh, a, b, radius, color, k, life) { mesh.position.copy(a).lerp(b, 0.5); mesh.lookAt(b); mesh.scale.set(radius, radius, a.distanceTo(b)); mesh.material.color.set(color).multiplyScalar(k); mesh.visible = true; mesh.userData.life = mesh.userData.max = life; mesh.userData.r = radius; }
const up = new THREE.Vector3(0, 1, 0), skidP = new THREE.Vector3(); let skidT = 0;
const onSkid = (x, y, z) => { burst(skidP.set(x, y, z), up, 2, 1.6, 0.42, 0.42, 0.42); if (skidT <= 0) { sfx.skid(); skidT = 0.09; } }; // tyre smoke

// ---------------------------------------------------------------- hostile camera drones
const drones = [], droneGroup = new THREE.Group(), shots = [];
function buildDrones() {
  scene.add(droneGroup);
  const disc = new THREE.MeshStandardMaterial({ color: 0x222222, transparent: true, opacity: 0.22, roughness: 0.5, depthWrite: false });
  for (let i = 0; i < 12; i++) {
    const g = new THREE.Group(), d = { g, alive: false, hp: 0, vel: new THREE.Vector3(), phase: rand(0, 6), cool: 2, props: [], side: i % 2 ? 1 : -1 };
    const m = (geo, mat, x = 0, y = 0, z = 0) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); o.castShadow = true; o.userData.drone = d; g.add(o); return o; };
    m(new RoundedBoxGeometry(0.3, 0.11, 0.42, 4, 0.05), M.white); m(new RoundedBoxGeometry(0.2, 0.05, 0.26, 3, 0.02), M.shroud, 0, 0.07, -0.02);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      m(new THREE.BoxGeometry(0.34, 0.03, 0.045), M.white, sx * 0.24, 0.02, sz * 0.22).rotation.y = -sx * sz * 0.75;
      m(new THREE.CylinderGeometry(0.03, 0.035, 0.07, 14), M.shroud, sx * 0.38, 0.05, sz * 0.34);
      d.props.push(m(new THREE.BoxGeometry(0.38, 0.004, 0.028), M.shroud, sx * 0.38, 0.095, sz * 0.34));
      m(new THREE.CylinderGeometry(0.19, 0.19, 0.003, 24), disc, sx * 0.38, 0.097, sz * 0.34).castShadow = false;
      m(new THREE.CylinderGeometry(0.008, 0.008, 0.16, 6), M.shroud, sx * 0.14, -0.12, sz * 0.14);
      m(new THREE.SphereGeometry(0.012, 8, 6), M.emit(sz > 0 ? 0xff2010 : 0x20ff40, 8), sx * 0.38, 0.0, sz * 0.34).castShadow = false;
    }
    m(new THREE.SphereGeometry(0.07, 20, 14), M.shroud, 0, -0.08, 0.17); m(new THREE.CylinderGeometry(0.035, 0.035, 0.03, 16), M.glass, 0, -0.08, 0.235).rotation.x = Math.PI / 2;
    d.eye = M.emit(0xff2408, 3); m(new THREE.SphereGeometry(0.018, 10, 8), d.eye, 0, -0.03, 0.215).castShadow = false;
    g.scale.setScalar(1.5); g.visible = false; droneGroup.add(g); drones.push(d);
  }
  const sg = new THREE.SphereGeometry(0.07, 12, 8), sm = new THREE.MeshBasicMaterial({ color: new THREE.Color(9, 2.2, 0.5), fog: false });
  for (let i = 0; i < 40; i++) { const o = new THREE.Mesh(sg, sm); o.visible = false; fx.add(o); shots.push({ m: o, vel: new THREE.Vector3(), life: 0 }); }
}
let wave = 0, waveTimer = 6, score = 0;
function spawnWave() {
  wave++; note(`Wave ${wave} — drones inbound`);
  const n = Math.min(2 + wave, drones.length);
  for (let i = 0; i < n; i++) { const d = drones[i], a = rand(0, 6.3), r = rand(80, 130); d.g.position.set(player.pos.x + Math.cos(a) * r, rand(22, 34), player.pos.z + Math.sin(a) * r); d.vel.set(0, 0, 0); d.hp = 55 + wave * 6; d.alive = true; d.cool = rand(2.5, 4.5); d.g.visible = true; }
}

// ---------------------------------------------------------------- RAM pickups (refill VRAM)
const rams = [];
function buildRam() {
  for (const [x, z] of [[-100, 138], [40, 46], [300, -984], [-10, -1228], [-1100, -2152], [-2142, -1868], [-2600, -695], [-8, 244], [79, 339.5], [600, -745], [POWER[0] - 70, POWER[1] + 61], [POWER[0] + 95, POWER[1] + 61], [-1283, -120], [-1904, -2940]]) {
    const r = makeRam(M); r.group.position.set(x, groundY(x, z) + 1.15, z); r.group.scale.setScalar(0.62); scene.add(r.group); rams.push({ ...r, x, z, respawn: 0 });
  }
}

// ---------------------------------------------------------------- shooting
const ray = new THREE.Raycaster(), v1 = new THREE.Vector3(), v2 = new THREE.Vector3(), v3 = new THREE.Vector3(), v4 = new THREE.Vector3();
let oc = false;
function hitDrone(d, dmg, point, n) {
  if (!d.alive) return; d.hp -= dmg; d.vel.addScaledVector(v1, 2); burst(point, n, 14, 5, 1.6, 0.9, 0.3); sfx.hit();
  const h = $('hit'); h.style.transition = 'none'; h.style.opacity = 1; requestAnimationFrame(() => { h.style.transition = 'opacity .25s'; h.style.opacity = 0; });
  if (d.hp <= 0) { d.alive = false; d.g.visible = false; score++; burst(d.g.position, v4.set(0, 0.4, 0), 130, 9, 2.2, 1.0, 0.3); burst(d.g.position, v4, 50, 3, 0.25, 0.25, 0.25); boomLight.position.copy(d.g.position); boomLight.intensity = 500; sfx.boom(); }
}
function fire(c) {
  const d = c.def, col = new THREE.Color(d.hex), dmg = d.dmg * (oc ? 1.6 : 1);
  player.vram -= d.vram; c.temp += d.heat; c.cool = d.rate; W.kick(); sfx.shot[W.cur]();
  player.pitch += d.kick * 0.008 + Math.random() * 0.003; player.yaw += rand(-0.004, 0.004) * d.kick;
  const moving = Math.hypot(player.vel.x, player.vel.z) > 1, sp = d.spread * (ads ? 0.3 : moving ? 2 : 1);
  v1.set(rand(-sp, sp), rand(-sp, sp), -1).normalize().transformDirection(camera.matrixWorld);
  ray.set(camera.getWorldPosition(v2), v1); ray.far = 600;
  const solid = ray.intersectObject(world.solids, true)[0], tW = v1.y < 0 ? -v2.y / v1.y : Infinity;
  const far = Math.min(solid ? solid.distance : 600, tW), end = v2.clone().addScaledVector(v1, far);
  ray.far = far; const seen = new Set(); let stop = null;
  for (const h of ray.intersectObject(droneGroup, true)) { const dr = h.object.userData.drone; if (!dr || seen.has(dr) || !dr.alive) continue; seen.add(dr); hitDrone(dr, dmg, h.point, v3.copy(v1).negate()); if (!d.ray) { stop = h.point; break; } }
  c.muzzle.getWorldPosition(v3);
  if (d.ray) streak(beam, v3, end, 0.035, col, 9, 0.28); else streak(tracers[tracerI = (tracerI + 1) % tracers.length], v3, stop || end, 0.006, col, 7, 0.05);
  if (stop) return;
  if (tW < (solid ? solid.distance : 600)) { burst(end, v3.set(0, 1, 0), d.ray ? 60 : 16, 4, 0.5, 0.6, 0.7); sfx.splash(); return; }
  if (!solid) return;
  const n = solid.face ? v3.copy(solid.face.normal).transformDirection(solid.object.matrixWorld) : v3.copy(v1).negate();
  burst(end, n, d.ray ? 50 : 10, d.ray ? 7 : 3.5, col.r * 2, col.g * 2, col.b * 2); burst(end, n, 6, 1.2, 0.15, 0.15, 0.15); sfx.impact();
  const dc = decals[decalI = (decalI + 1) % decals.length]; dc.position.copy(end).addScaledVector(n, 0.02); dc.lookAt(v4.copy(end).add(n)); dc.rotateZ(rand(0, 6.3)); dc.scale.setScalar(rand(0.7, 1.2) * (d.ray ? 3 : 1)); dc.visible = true;
}
function hurt(dmg) {
  if (player.hp <= 0 || transit.safe) return;
  player.hp -= dmg * (driving ? 0.5 : 1); player.lastHurt = now; film.uniforms.hurt.value = 1; sfx.hurt();
  if (player.hp <= 0) { player.hp = 0; $('msg').textContent = `Shut down — ${score} drones destroyed, wave ${wave}. ${ui.touch ? 'Tap' : 'Click'} to reboot`; touchPlay = false; overlay.style.display = 'flex'; document.exitPointerLock?.(); }
}
function resetGame() {
  player.pos.set(SPAWN[0], LAND_Y, SPAWN[1]); player.vel.set(0, 0, 0); player.yaw = -0.3; player.pitch = 0.03; player.hp = 100; player.vram = 16; driving = null; wave = 0; waveTimer = 6; score = 0;
  for (const c of W.cards) { c.temp = 38; c.throttled = false; } for (const d of drones) { d.alive = false; d.g.visible = false; } for (const s of shots) { s.life = 0; s.m.visible = false; }
}

// ---------------------------------------------------------------- movement modes
let now = 0, stepT = 0, fps = 60, bobX = 0, bobY = 0;
function walk(dt) {
  const p = player.pos, f = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0) + ui.moveY, s = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0) + ui.moveX, mag = Math.max(1, Math.hypot(f, s));
  const sprint = (keys.ShiftLeft || ui.moveY > 0.92) && f > 0 && !ads, sp = (ads ? 2.4 : sprint ? 7.4 : 4.5) / mag;
  const sy = Math.sin(player.yaw), cy = Math.cos(player.yaw), k = player.onGround ? 12 : 2.5;
  player.vel.x = damp(player.vel.x, (-sy * f + cy * s) * sp, k, dt); player.vel.z = damp(player.vel.z, (-cy * f - sy * s) * sp, k, dt); player.vel.y -= 21 * dt;
  if (keys.Space && player.onGround) { player.vel.y = 6.7; player.onGround = false; }
  const nx = p.x + player.vel.x * dt; if (!blocked(nx, p.y, p.z)) p.x = nx; else player.vel.x = 0;
  const nz = p.z + player.vel.z * dt; if (!blocked(p.x, p.y, nz)) p.z = nz; else player.vel.z = 0;
  p.y += player.vel.y * dt;
  const gY = groundAt(p.x, p.y, p.z);
  if (p.y <= gY || (player.onGround && player.vel.y <= 0 && p.y - gY < 0.4)) { if (player.vel.y < -8) W.recoil += 0.8; p.y = gY; player.vel.y = 0; player.onGround = true; } else player.onGround = false;
  const hs = Math.hypot(player.vel.x, player.vel.z), amp = Math.min(1, hs / 4);
  if (player.onGround && hs > 0.5) { player.bob += hs * dt * 1.9; stepT -= hs * dt; if (stepT < 0) { stepT = 2.3; sfx.step(); } }
  bobY = Math.sin(player.bob * 2) * 0.022 * amp; bobX = Math.cos(player.bob) * 0.014 * amp;
  camera.position.set(p.x, p.y + EYE + bobY, p.z); camera.rotation.set(player.pitch, player.yaw, bobX * 0.4);
  camera.fov = damp(camera.fov, ads ? 46 : sprint ? 78 : 72, 14, dt); camera.updateProjectionMatrix(); camera.updateMatrixWorld();
}
let orbit = 0;
function drive(dt) { // third-person chase camera; drag / mouse swings it round the car to enjoy the view
  const c = driving, back = 6.8 + Math.abs(c.v) * 0.07;
  player.pos.copy(c.pos); player.vel.set(c.vx, 0, c.vz); player.onGround = true; bobX = bobY = 0;
  orbit = damp(orbit + -mdx * 0.004, 0, Math.abs(mdx) > 0.5 ? 0 : 0.6, dt); const a = c.heading + orbit;
  v4.set(c.pos.x + Math.sin(a) * back, c.pos.y + 2.5 + Math.max(-1.2, Math.min(3, player.pitch * -3)), c.pos.z + Math.cos(a) * back);
  camera.position.lerp(v4, 1 - Math.exp(-7 * dt)); camera.lookAt(c.pos.x, c.pos.y + 1.2, c.pos.z);
  camera.fov = damp(camera.fov, 62 + Math.abs(c.v) * 0.55, 4, dt); camera.updateProjectionMatrix(); camera.updateMatrixWorld();
}

// ---------------------------------------------------------------- per-frame game update (only while playing)
function update(dt, t) {
  const p = player.pos; skidT -= dt;
  if (ui.autoTap) { ui.autoTap = false; if (driving) toggleAuto(); }
  if (ui.touch) { firing = ui.fire; if (ui.fire && !W.card.def.auto && W.card.cool <= 0) trig = true; ads = ui.aim; }
  const thr = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0), steer = (keys.KeyA ? 1 : 0) - (keys.KeyD ? 1 : 0) - (Math.abs(ui.moveX) > 0.15 ? ui.moveX : 0);
  cars.update(dt, driving, driving ? { thr, steer: Math.max(-1, Math.min(1, steer)), brake: !!keys.Space } : null);
  const riding = transit.update(dt, player);
  if (!riding) { if (driving) drive(dt); else walk(dt); }
  W.root.visible = !driving && !riding;

  // power: overclock near energy facilities
  const zone = zones.find((z) => Math.hypot(p.x - z.x, p.z - z.z) < z.r); if (!!zone !== oc) { oc = !!zone; if (oc) note(`Overclock — ${zone.name}`); }
  if (oc) player.vram = Math.min(VRAM_MAX, player.vram + 0.9 * dt);
  for (const c of W.cards) {
    c.cool -= dt; c.temp = Math.max(38, c.temp - (c === W.card ? 13 : 22) * (oc ? 1.7 : 1) * dt);
    if (c.temp >= 95 && !c.throttled) { c.throttled = true; sfx.throttle(); note('Thermal throttle'); } else if (c.throttled && c.temp < 66) c.throttled = false;
  }
  const c = W.card, want = c.def.auto ? firing : trig; trig = false;
  if (want && !driving && !riding && W.swap <= 0 && c.cool <= 0 && !c.throttled) { if (player.vram >= c.def.vram) fire(c); else { sfx.click(); note('Out of VRAM — find RAM'); c.cool = 0.4; } }
  W.update(dt, { ads, bobX, bobY, mdx, mdy, t, vy: player.vel.y }); mdx = mdy = 0;
  const heat = (c.temp - 38) / 57, spd = driving ? Math.abs(driving.v) : 0; hum(driving ? 0.012 + spd * 0.0015 : riding ? 0.02 : 0.004 + heat * 0.05, driving ? 110 + spd * 42 : riding ? 140 : 160 + heat * 520);
  if (t - player.lastHurt > 5 && player.hp < 100) player.hp = Math.min(100, player.hp + 10 * dt);

  for (const r of rams) {
    if (r.respawn > 0) { r.respawn -= dt; r.group.visible = r.respawn <= 0; continue; }
    if (Math.hypot(p.x - r.x, p.z - r.z) < (driving ? 2.6 : 1.5) && player.vram < VRAM_MAX - 0.5) { player.vram = Math.min(VRAM_MAX, player.vram + 8); r.respawn = 25; r.group.visible = false; sfx.pickup(); note('+8 GB VRAM'); }
  }

  // drones
  let alive = 0; const head = v2.set(p.x, p.y + 1.4, p.z);
  for (const d of drones) {
    if (!d.alive) continue; alive++;
    const g = d.g, to = v1.copy(head).sub(g.position), dist = to.length();
    const ang = Math.atan2(g.position.z - p.z, g.position.x - p.x) + d.side * 0.45, pref = 11 + 4 * Math.sin(t * 0.3 + d.phase);
    v3.set(p.x + Math.cos(ang) * pref, p.y + 4.2 + Math.sin(t * 0.8 + d.phase) * 1.2, p.z + Math.sin(ang) * pref);
    d.vel.addScaledVector(v3.sub(g.position).clampLength(0, 30), 1.5 * dt);
    for (const o of drones) if (o !== d && o.alive) { v3.copy(g.position).sub(o.g.position); const l = v3.length(); if (l < 2.6) d.vel.addScaledVector(v3, (2.6 - l) * 3 * dt / (l + 0.01)); }
    d.vel.multiplyScalar(Math.exp(-1.3 * dt)); g.position.addScaledVector(d.vel, dt); g.position.y = Math.max(groundY(g.position.x, g.position.z) + 1.6, g.position.y);
    g.lookAt(head); g.rotateX(-0.25); g.rotateZ(-d.vel.dot(v3.set(1, 0, 0).applyQuaternion(g.quaternion)) * 0.06);
    for (const pr of d.props) pr.rotation.y += 70 * dt;
    d.cool -= dt; d.eye.emissiveIntensity = 3 + Math.max(0, 1 - d.cool) * 40; // lens flares up before a shot
    if (d.cool <= 0 && dist < 45 && !transit.safe) {
      d.cool = rand(1.8, 3.2) * Math.max(0.55, 1 - wave * 0.04);
      ray.set(g.position, to.normalize()); ray.far = dist; const sh = shots.find((x) => x.life <= 0);
      if (sh && !ray.intersectObject(world.solids, true).length) { sh.m.position.copy(g.position).addScaledVector(to, 0.5); sh.vel.copy(to).multiplyScalar(20).addScaledVector(player.vel, 0.3); sh.life = 4; sh.m.visible = true; sfx.droneShot(); }
    }
  }
  if (!alive) { waveTimer -= dt; if (waveTimer <= 0) { spawnWave(); waveTimer = 8; } }
  for (const sh of shots) {
    if (sh.life <= 0) continue; sh.life -= dt; const m = sh.m; m.position.addScaledVector(sh.vel, dt); let dead = sh.life <= 0;
    if (m.position.distanceTo(head) < 0.6) { hurt(7); dead = true; }
    else if (m.position.y < 0 || (walkable(m.position.x, m.position.z) && m.position.y < groundY(m.position.x, m.position.z))) { dead = true; burst(m.position, v3.set(0, 1, 0), 10, 3, 2, 0.6, 0.2); }
    else if (world.near(m.position.x, m.position.z).polys.some((q) => m.position.y < q.h + LAND_Y && pipFlat(q.pts, m.position.x, m.position.z))) { dead = true; burst(m.position, v3.copy(sh.vel).normalize().negate(), 10, 3, 2, 0.6, 0.2); }
    else for (const b of world.near(m.position.x, m.position.z).boxes) if (b.containsPoint(m.position)) { dead = true; burst(m.position, v3.copy(sh.vel).normalize().negate(), 10, 3, 2, 0.6, 0.2); break; }
    if (dead) { sh.life = 0; m.visible = false; }
  }

  // HUD (monitoring-overlay style)
  const tc = c.temp > 80 ? 'hot' : '', bar = (v) => '█'.repeat(Math.round(Math.max(0, Math.min(1, v)) * 12)).padEnd(12, '░');
  const prompt = driving || riding ? '' : cars.nearest(p, 3.6) ? 'E — drive this car' : transit.prompt(p);
  const carLine = driving ? `${Math.abs(driving.v * 3.6).toFixed(0)} km/h${driving.slip > 3.2 ? ' <span class="hot">DRIFT</span>' : ''}${driving.auto ? ' <span class="oc">AUTO</span>' : ''}` : '—';
  $('osd').innerHTML = `<b>GPU </b> ${c.def.name}\n<b>TEMP</b> <span class="${tc}">${c.temp.toFixed(0).padStart(3)}°C ${bar(heat)}</span>${c.throttled ? ' <span class="hot">THROTTLED</span>' : ''}\n<b>VRAM</b> ${player.vram.toFixed(1).padStart(4)} / ${VRAM_MAX} GB ${bar(player.vram / VRAM_MAX)}\n<b>PWR </b> ${oc ? '<span class="oc">OVERCLOCK +60%</span>' : 'STOCK'}\n<b>FPS </b> ${fps.toFixed(0)}\n<b>CAR </b> ${carLine}`;
  $('hp').textContent = Math.ceil(player.hp); $('hpb').style.width = player.hp + '%';
  $('wname').textContent = c.def.name; $('wsub').textContent = c.def.sub;
  $('slots').innerHTML = W.cards.map((x, i) => `<div class="${i === W.next ? 'on' : ''}">${i + 1} · ${x.def.name}${x.throttled ? ' — hot' : ''}</div>`).join('');
  $('top').textContent = prompt || (alive ? `Wave ${wave} · ${alive} drone${alive > 1 ? 's' : ''} · ${score} destroyed` : `Wave ${wave + 1} inbound`);
  $('cross').style.opacity = driving || riding ? 0 : 1 - W.adsT;
  if (noteT > 0 && (noteT -= dt) <= 0) $('note').style.opacity = 0;
  ui.mode(!!driving, riding, driving?.auto, prompt);
}
// ambient animation that keeps running behind the menu
let lampT = 0, mapT = 0;
function updateFx(dt, t) {
  for (let i = 0; i < SP; i++) {
    if (spLife[i] <= 0) continue; spLife[i] -= dt; const j = i * 3;
    spVel[j + 1] -= 9.8 * dt; spPos[j] += spVel[j] * dt; spPos[j + 1] += spVel[j + 1] * dt; spPos[j + 2] += spVel[j + 2] * dt;
    const k = Math.exp(-4 * dt); spCol[j] *= k; spCol[j + 1] *= k * k; spCol[j + 2] *= k * k; if (spLife[i] <= 0) spPos[j + 1] = -99;
  }
  sparks.geometry.attributes.position.needsUpdate = sparks.geometry.attributes.color.needsUpdate = true;
  for (const tr of [...tracers, beam]) if (tr.visible) { tr.userData.life -= dt; const q = tr.userData.life / tr.userData.max; if (q <= 0) tr.visible = false; else tr.scale.x = tr.scale.y = tr.userData.r * q; }
  boomLight.intensity = damp(boomLight.intensity, 0, 9, dt);
  for (const r of rams) { r.group.rotation.y = t * 1.2 + r.x; r.group.position.y = groundY(r.x, r.z) + 1.15 + Math.sin(t * 2 + r.z) * 0.08; r.rgb.emissive.setHSL((t * 0.25 + r.x * 0.01) % 1, 1, 0.5); }
  for (const fn of world.tick) fn(t);
  if ((lampT -= dt) <= 0 && world.lamps.length) { // hand the real lights to the nearest lamp posts
    lampT = 0.3; const c = player.pos, near = world.lamps.map((l) => [Math.hypot(l[0] - c.x, l[1] - c.z), l]).sort((a, b) => a[0] - b[0]);
    lampLights.forEach((l, i) => { const [x, z] = near[i][1]; l.position.set(x, groundY(x, z) + 3.6, z); });
  }
  if ((mapT -= dt) <= 0) { mapT = 0.12; ui.drawMap({ x: player.pos.x, z: player.pos.z, yaw: driving ? driving.heading : player.yaw, cars: cars.list, ferry: transit.ferry.position }); }
  env.update(t, dt, camera.position.y < -10 ? player.pos : camera.position);
  film.uniforms.time.value = t; film.uniforms.hurt.value = damp(film.uniforms.hurt.value, player.hp < 35 ? 0.35 : 0, 3, dt);
}

// ---------------------------------------------------------------- post-processing
function buildPost() {
  const w = innerWidth, h = innerHeight;
  composer = new EffectComposer(renderer); composer.addPass(new RenderPass(scene, camera));
  const gtao = new GTAOPass(scene, camera, w, h), gr = gtao.render.bind(gtao);
  gtao.render = (...a) => { const fv = W.flash.visible; fx.visible = W.flash.visible = false; for (const o of world.noAO) o.visible = false; gr(...a); for (const o of world.noAO) o.visible = true; fx.visible = true; W.flash.visible = fv; };
  composer.addPass(gtao);
  composer.addPass(new UnrealBloomPass(new THREE.Vector2(w, h), 0.05, 0.4, 4.0));
  composer.addPass(new OutputPass()); composer.addPass(new SMAAPass());
  film = new ShaderPass({ uniforms: { tDiffuse: { value: null }, time: { value: 0 }, hurt: { value: 0 } },
    vertexShader: 'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: `uniform sampler2D tDiffuse;uniform float time,hurt;varying vec2 vUv;
      void main(){vec2 c=vUv-.5;float d=dot(c,c);vec2 o=c*d*.008;
        vec3 col=vec3(texture2D(tDiffuse,vUv+o).r,texture2D(tDiffuse,vUv).g,texture2D(tDiffuse,vUv-o).b);
        col*=1.-d*.7; float n=fract(sin(dot(gl_FragCoord.xy+fract(time)*91.7,vec2(12.9898,78.233)))*43758.5453); col+=(n-.5)*.02;
        col=mix(col,vec3(.55,0.,0.),clamp(hurt*d*3.,0.,.8)); gl_FragColor=vec4(col,1.);}` });
  composer.addPass(film);
}
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); composer?.setSize(innerWidth, innerHeight); });

// ---------------------------------------------------------------- boot
function boot() {
  M = makeMats(renderer); env = buildEnv(scene, renderer); world = buildWorld(scene, M);
  const city = buildCity(world, { SUN, FOG, FOG_COLOR }); buildScenery(world); // city first, so nothing gets planted inside a building
  // energy site (substation, battery storage, solar charging hub) on open ground west of Yanggongdi, with its own access road
  const pw = buildPower(world.shifted(POWER[0], POWER[1]));
  zones = pw.zones.map((z) => ({ ...z, x: z.x + POWER[0], z: z.z + POWER[1] }));
  world.ribbon(world.dense([[-1904, -2956], [-1900, -3010], [-1900, -3072]]), 9, world.over(M.asphalt, 4), LAND_Y + 0.07);
  world.ribbon(world.dense([[-2030, -3078], [-1780, -3078]]), 12, world.over(M.asphalt, 4), LAND_Y + 0.07);
  const spots = [...pw.carSpots.slice(0, 3).map(([x, z, h]) => [x + POWER[0], z + POWER[1], h]),
    [-70, 128, 2.1], [-60, 152, 2.1], [-6, 262, -1.57], [140, 352, 3.14], [-640, 62, 1.2], [640, -690, 0.4], [-2725, -700, 1.4], [-1560, -2712, 0], [-2150, -1866, -1.3]]; // the first is on Hubin Road; the rest are parked clear of the ring
  cars = createCars(world, spots, M, onSkid); cars.update(0.016, null, null);
  ui = createUI({ keys, onLook: look, onUse: () => playing() && use(), onSwap: () => W.select((W.next + 1) % 3) });
  transit = createTransit(world, camera, city.metro, (s) => { note(s); sfx.chime(); });
  W = createWeapons(camera, M); buildFx(); buildDrones(); buildRam(); buildPost();
  // self-check: open water blocks, the promenade, the Broken Bridge crest and the Su Causeway do not; the bridge really humps
  console.assert(blocked(-600, LAND_Y, -900) && !blocked(SPAWN[0], LAND_Y, SPAWN[1]) && blocked(-200, LAND_Y, 420) && walkable(532, -822) && walkable(-1100, -2152) && walkable(-2784, -700), 'collision self-check failed');
  console.assert(groundY(532, -822) > LAND_Y + 2 && groundY(0, 300) === LAND_Y, 'ground self-check failed');
  camera.position.set(player.pos.x, player.pos.y + EYE, player.pos.z); camera.rotation.set(player.pitch, player.yaw, 0);
  W.update(0.016, { ads: false, bobX: 0, bobY: 0, mdx: 0, mdy: 0, t: 0, vy: 0 }); ui.mode(false, false, false, '');
  started = true; $('msg').textContent = ui.touch ? 'Tap to start' : 'Click to deploy';
  window.G = { scene, camera, player, renderer, world, env, W, drones, rams, cars, keys, ui, transit, use, blocked, POI, get driving() { return driving; }, spawnWave, hurt, fire: () => fire(W.card), step: (dt) => { now += dt; update(dt, now); } }; // debug + smoke test
  let last = performance.now();
  renderer.setAnimationLoop((ms) => {
    const dt = Math.min((ms - last) / 1000, 0.05); last = ms; fps = damp(fps, 1 / Math.max(dt, 1e-3), 2, dt);
    if (playing() && player.hp > 0) { now += dt; update(dt, now); }
    updateFx(dt, ms / 1000); composer.render(dt);
  });
}
setTimeout(boot, 60); // let the loading text paint first
