﻿西湖 · OVERCLOCK  |  80 人公司混战

1. 用 Windows 自带的解压功能选择“全部解压缩”。
2. 打开解压后的 West Lake Overclock 文件夹，双击 Play West Lake.exe。
3. 游戏会在默认浏览器中打开。游玩时保持启动窗口开启。
   浏览器没有自动打开时，将启动窗口里的本地地址复制到支持 WebGL 2 的浏览器。
4. 关掉启动窗口即可停止游戏。无需联网、安装 Python 或 Node.js。

P 切换画质。T 切换追踪公司。M 打开地图。详细操作在游戏开始界面。
玩家和机器人共有 20 支队伍，每队 4 人。公司阵营属于虚构的游戏设定。

车辆模型来源见 westlake\vehicle-assets\CREDITS.md。
地图数据 © OpenStreetMap contributors（ODbL）。
Three.js 许可见 node_modules\three\LICENSE。

Windows offline edition. Extract all files, then double-click Play West Lake.exe.
Leave the launcher window open while playing. To stop the local server, close it.
