using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

internal static class Launcher
{
    private static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    private static readonly Semaphore Connections = new Semaphore(20, 20);
    private static string host;

    public static int Main(string[] args)
    {
        try
        {
            if (!File.Exists(Path.Combine(Root, "westlake", "index.html")))
                throw new IOException("Game files are missing. Extract all files from the ZIP first.");

            TcpListener listener = Listen(18874);
            host = "127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port;
            string url = "http://" + host + "/westlake/";
            Console.WriteLine(url);
            Console.WriteLine("Leave this window open while playing. Close it to stop the game server.");
            if (Array.IndexOf(args, "--no-browser") < 0)
            {
                try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
                catch (Exception) { Console.WriteLine("Open the address above in your browser."); }
            }

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                if (!Connections.WaitOne(0)) { client.Close(); continue; }
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try { using (client) Serve(client); }
                    catch (IOException) { }
                    catch (SocketException) { }
                    finally { Connections.Release(); }
                });
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.Message);
            if (!Console.IsInputRedirected)
            {
                Console.Error.WriteLine("Press Enter to exit.");
                Console.ReadLine();
            }
            return 1;
        }
    }

    private static TcpListener Listen(int port)
    {
        TcpListener listener = new TcpListener(IPAddress.Loopback, port);
        listener.ExclusiveAddressUse = true;
        try { listener.Start(32); }
        catch (SocketException ex)
        {
            listener.Stop();
            if (port != 0 && (ex.SocketErrorCode == SocketError.AddressAlreadyInUse || ex.SocketErrorCode == SocketError.AccessDenied))
                return Listen(0);
            throw;
        }
        return listener;
    }

    private static void Serve(TcpClient client)
    {
        client.ReceiveTimeout = client.SendTimeout = 5000;
        NetworkStream stream = client.GetStream();
        byte[] header = new byte[8192];
        int length = 0;
        while (length < header.Length)
        {
            int read = stream.Read(header, length, header.Length - length);
            if (read == 0) return;
            length += read;
            if (Encoding.ASCII.GetString(header, 0, length).Contains("\r\n\r\n")) break;
        }
        string raw = Encoding.ASCII.GetString(header, 0, length);
        int end = raw.IndexOf("\r\n\r\n", StringComparison.Ordinal);
        if (end < 0) { Reply(stream, "400 Bad Request", null, 0); return; }
        string[] lines = raw.Substring(0, end).Split(new[] { "\r\n" }, StringSplitOptions.None);
        string[] request = lines[0].Split(' ');
        if (request.Length != 3 || !Array.Exists(lines, line => line.StartsWith("Host:", StringComparison.OrdinalIgnoreCase) && line.Substring(5).Trim() == host))
        {
            Reply(stream, "400 Bad Request", null, 0);
            return;
        }
        bool head = request[0] == "HEAD";
        if (request[0] != "GET" && !head) { Reply(stream, "405 Method Not Allowed", null, 0); return; }

        if (request[1] == "/favicon.ico") { Reply(stream, "204 No Content", null, 0); return; }
        string path = Resolve(request[1]);
        string mime = path == null ? null : ContentType(Path.GetExtension(path));
        if (mime == null || !File.Exists(path)) { Reply(stream, "404 Not Found", null, 0); return; }
        using (FileStream file = File.OpenRead(path))
        {
            Reply(stream, "200 OK", mime, file.Length);
            if (!head) file.CopyTo(stream);
        }
    }

    private static string Resolve(string target)
    {
        string path = Uri.UnescapeDataString(target.Split('?')[0]);
        if (path == "/" || path == "/westlake/") path = "/westlake/index.html";
        if (!path.StartsWith("/westlake/", StringComparison.Ordinal) &&
            !path.StartsWith("/node_modules/three/", StringComparison.Ordinal)) return null;
        string[] parts = path.Substring(1).Split('/');
        foreach (string part in parts)
        {
            if (part.Length == 0 || part == "." || part == ".." ||
                part.EndsWith(".", StringComparison.Ordinal) || part.EndsWith(" ", StringComparison.Ordinal) ||
                part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0) return null;
        }
        return Path.Combine(Root, Path.Combine(parts));
    }

    private static string ContentType(string extension)
    {
        switch (extension.ToLowerInvariant())
        {
            case ".html": return "text/html; charset=utf-8";
            case ".css": return "text/css; charset=utf-8";
            case ".js": return "text/javascript; charset=utf-8";
            case ".glb": return "model/gltf-binary";
            case ".svg": return "image/svg+xml";
            default: return null;
        }
    }

    private static void Reply(NetworkStream stream, string status, string mime, long length)
    {
        string response = "HTTP/1.1 " + status + "\r\nConnection: close\r\nContent-Length: " + length + "\r\n" +
            (mime == null ? "" : "Content-Type: " + mime + "\r\n") +
            "X-Content-Type-Options: nosniff\r\n\r\n";
        byte[] bytes = Encoding.ASCII.GetBytes(response);
        stream.Write(bytes, 0, bytes.Length);
    }
}

